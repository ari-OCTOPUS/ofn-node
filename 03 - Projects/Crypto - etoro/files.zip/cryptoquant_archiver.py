#!/usr/bin/env python3
"""
CryptoQuant Full-Archive Extractor (api v1)
-------------------------------------------
Strategy: CryptoQuant has NO "dump everything" call, but /discovery/endpoints
returns every endpoint YOUR plan can access, with its parameter options. We
walk that list and pull each metric's full daily history in a single call
(limit=100000, window=day reaches back as far as they track).

Auth: Authorization: Bearer <access_token>   (Professional/Premium plans only)
Response shape: data["result"]["data"] = list of rows.

Output: raw JSON (source of truth) + Parquet (fast queries).
Resumable: files already on disk are skipped on re-run.
Rate-limit aware: sleeps + exponential backoff on 429/5xx.

Run:  export CQ_KEY="your_access_token"
      python3 cryptoquant_archiver.py discover   # see what your plan unlocks (1 call)
      python3 cryptoquant_archiver.py pull        # archive everything (resumable)
      python3 cryptoquant_archiver.py all
"""

import os, sys, re, json, time, datetime as dt, subprocess
from pathlib import Path

import requests
import pandas as pd

# auto-install pyarrow on Windows if missing
try:
    import pyarrow  # noqa
except ImportError:
    print("pyarrow not found — installing...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyarrow"])
    print("pyarrow installed. rerun the script.")

# ----------------------------- CONFIG -----------------------------
API_KEY  = os.environ.get("CQ_KEY", "").strip()
BASE     = "https://api.cryptoquant.com/v1"
OUT      = Path("./cq_archive")
SLEEP    = 2.0                       # seconds between calls; raise if you hit 429
EARLIEST = "20100101"                # from-date; API returns as far back as it has
LIMIT    = 100000                    # max rows per call (full daily history in one shot)

# Keep call count sane: for these params use ONE sensible default instead of
# iterating every option. Set ITERATE_EXCHANGES=True only if you want per-exchange
# granularity (multiplies calls by ~number of exchanges).
ITERATE_EXCHANGES = False
EXCHANGE_DEFAULT  = "all_exchange"
MARKET_DEFAULT    = "spot"
FIXED_PARAMS      = {"exchange", "market", "window"}   # not enumerated
# ------------------------------------------------------------------

if not API_KEY:
    sys.exit("Set your key first:  export CQ_KEY='...'")

HEADERS = {"Authorization": f"Bearer {API_KEY}"}
OUT.mkdir(exist_ok=True)
TODAY = dt.date.today().isoformat()


def get(path, params=None, max_retries=6):
    url = f"{BASE}{path}"
    delay = SLEEP
    for _ in range(max_retries):
        try:
            r = requests.get(url, headers=HEADERS, params=params, timeout=60)
        except requests.RequestException as e:
            print(f"  net error {e}; retry {delay:.0f}s"); time.sleep(delay); delay *= 2; continue
        if r.status_code == 200:
            time.sleep(SLEEP)
            return r.json()
        if r.status_code in (429, 500, 502, 503, 504):
            print(f"  {r.status_code}; backoff {delay:.0f}s"); time.sleep(delay); delay *= 2; continue
        if r.status_code in (401, 403):
            sys.exit(f"AUTH FAILED ({r.status_code}) — token dead or out of quota. STOP.")
        return {"_http_error": r.status_code, "_body": r.text[:200]}
    return None


def safe_name(s):
    return re.sub(r"[^a-zA-Z0-9._-]", "_", s).strip("_")


def discover():
    print("[discover]")
    d = get("/discovery/endpoints")
    if not d or "result" not in d:
        sys.exit(f"discovery failed: {d}")
    eps = d["result"]["data"]
    (OUT / "discovery_endpoints.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"  {len(eps)} endpoints your plan can access -> cq_archive/discovery_endpoints.json")
    return eps


def param_combos(parameters):
    """Build a small list of query-param dicts to cover an endpoint's metrics.
    - window fixed to day, exchange/market fixed to defaults
    - other enum params (type, token, symbol, status, ...) are iterated fully
    """
    base = {"window": "day", "from": EARLIEST, "limit": LIMIT, "format": "json"}
    # parameters is a list of {name: [allowed values]} (or free-form dicts)
    enum_params = {}
    for p in (parameters or []):
        if not isinstance(p, dict):
            continue
        for name, opts in p.items():
            if name in ("from", "to", "limit", "format"):
                continue
            if name == "exchange":
                if ITERATE_EXCHANGES and isinstance(opts, list):
                    enum_params["exchange"] = opts
                else:
                    base["exchange"] = EXCHANGE_DEFAULT if (not isinstance(opts, list) or EXCHANGE_DEFAULT in opts) else opts[0]
            elif name == "market":
                base["market"] = MARKET_DEFAULT if (not isinstance(opts, list) or MARKET_DEFAULT in opts) else opts[0]
            elif name == "window":
                continue  # fixed to day
            elif isinstance(opts, list) and 0 < len(opts) <= 30:
                enum_params[name] = opts  # iterate distinct metric variants

    if not enum_params:
        return [base]
    # cartesian product of enum params
    combos = [base]
    for name, opts in enum_params.items():
        new = []
        for c in combos:
            for v in opts:
                cc = dict(c); cc[name] = v; new.append(cc)
        combos = new
    return combos


def pull(eps):
    print(f"[pull] {len(eps)} endpoints")
    for i, ep in enumerate(eps, 1):
        path = ep.get("path") or ep.get("endpoint")
        if not path:
            continue
        combos = param_combos(ep.get("parameters"))
        for params in combos:
            tag = "_".join(f"{k}-{v}" for k, v in params.items()
                           if k not in ("from", "limit", "format", "window"))
            rel = f"data/{safe_name(path.strip('/'))}{('__' + safe_name(tag)) if tag else ''}"
            if (OUT / f"{rel}.parquet").exists() or (OUT / f"{rel}.empty").exists():
                continue
            d = get(path, params)
            if isinstance(d, dict) and d.get("_http_error"):
                # often a param mismatch; try the bare minimum once
                d = get(path, {"window": "day", "from": EARLIEST, "limit": LIMIT})
            rows = (d or {}).get("result", {}).get("data") if isinstance(d, dict) else None
            p = OUT / f"{rel}.json"
            p.parent.mkdir(parents=True, exist_ok=True)
            if rows:
                p.write_text(json.dumps(d, ensure_ascii=False), encoding='utf-8')
                try:
                    pd.DataFrame(rows).to_parquet(OUT / f"{rel}.parquet", index=False)
                except Exception as e:
                    csv_p = (OUT / f"{rel}.csv")
                    pd.DataFrame(rows).to_csv(csv_p, index=False, encoding='utf-8')
                    print(f"    saved as csv (parquet unavailable: {e})")
                print(f"  {i}/{len(eps)} {path} [{tag or 'default'}]: {len(rows)} rows")
            else:
                (OUT / f"{rel}.empty").write_text(json.dumps(d, ensure_ascii=False)[:500], encoding='utf-8')
                print(f"  {i}/{len(eps)} {path} [{tag or 'default'}]: empty/err")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    t0 = time.time()
    eps = discover()
    if cmd in ("pull", "all"):
        pull(eps)
    print(f"done in {(time.time()-t0)/60:.1f} min  ->  {OUT.resolve()}")
