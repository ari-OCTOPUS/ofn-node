#!/usr/bin/env python3
"""
LunarCrush Full-Archive Extractor (api4)
----------------------------------------
Pulls everything you can pull before your subscription dies:
  - SNAPSHOTS (re-pull DAILY, can never be backfilled): full coin list, stock list, topic 24h summaries
  - TIME-SERIES (pull ONCE with max history): per-coin market+social history, per-topic social history
  - CREATORS: list + per-creator time series

Output: raw JSON (source of truth) + Parquet (fast research queries).
Resumable: already-downloaded time-series files are skipped on re-run.
Rate-limit aware: sleeps between calls, exponential backoff on 429/5xx.

Run:  export LC_KEY="your_bearer_key"
      python3 lunarcrush_archiver.py snapshots      # run this EVERY DAY
      python3 lunarcrush_archiver.py timeseries     # run this ONCE (resumable)
      python3 lunarcrush_archiver.py creators        # run this ONCE
      python3 lunarcrush_archiver.py all             # everything
"""

import os, sys, json, time, datetime as dt, subprocess
from pathlib import Path

import requests
import pandas as pd

# auto-install pyarrow on Windows if missing
try:
    import pyarrow  # noqa
except ImportError:
    print("pyarrow not found — installing...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyarrow"])
    print("pyarrow installed. rerun the script.")

# ----------------------------- CONFIG -----------------------------
API_KEY   = os.environ.get("LC_KEY", "").strip()
BASE      = "https://lunarcrush.com/api4/public"
OUT       = Path("./lc_archive")          # everything lands here
SLEEP     = 6.0                            # seconds between calls; raise if you hit 429
TOP_N     = 1000                           # how many coins to pull time-series for (by mcap)
EARLIEST  = int(dt.datetime(2018, 1, 1).timestamp())  # ask for history back to here

# Your explicit watchlist ALWAYS gets pulled at full history, even outside TOP_N.
WATCHLIST_COINS  = ["BTC", "ETH", "HYPE", "XAN", "SWARMS", "PENGU", "HAC", "VVV"]
WATCHLIST_TOPICS = ["bitcoin", "ethereum", "hyperliquid", "anoma", "swarms"]
WATCHLIST_STOCKS = []   # e.g. ["NVDA","TSM"] — stocks use the same time-series endpoint shape
# ------------------------------------------------------------------

if not API_KEY:
    sys.exit("Set your key first:  export LC_KEY='...'")

HEADERS = {"Authorization": f"Bearer {API_KEY}"}
OUT.mkdir(exist_ok=True)
TODAY = dt.date.today().isoformat()


def get(path, params=None, max_retries=6):
    """GET with backoff. Returns parsed JSON or None on hard failure."""
    url = f"{BASE}{path}"
    delay = SLEEP
    for attempt in range(max_retries):
        try:
            r = requests.get(url, headers=HEADERS, params=params, timeout=45)
        except requests.RequestException as e:
            print(f"  net error {e}; retry in {delay:.0f}s")
            time.sleep(delay); delay *= 2; continue

        if r.status_code == 200:
            time.sleep(SLEEP)            # be polite even on success
            return r.json()
        if r.status_code in (429, 500, 502, 503, 504):
            print(f"  {r.status_code} on {path}; backoff {delay:.0f}s")
            time.sleep(delay); delay *= 2; continue
        if r.status_code in (401, 403):
            sys.exit(f"AUTH FAILED ({r.status_code}) — key dead or out of quota. STOP.")
        print(f"  {r.status_code} on {path}: {r.text[:160]}")
        return None
    print(f"  gave up on {path}")
    return None


def save_json(obj, relpath):
    p = OUT / relpath
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')
    return p


def save_parquet(rows, relpath):
    if not rows:
        return None
    p = OUT / relpath
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        pd.DataFrame(rows).to_parquet(p, index=False)
    except Exception as e:
        csv_p = p.with_suffix('.csv')
        pd.DataFrame(rows).to_csv(csv_p, index=False, encoding='utf-8')
        print(f"  saved as csv (parquet unavailable: {e})")
    return p


# ----------------------------- SNAPSHOTS -----------------------------
# These reflect the CURRENT state of the market. They are IRREPLACEABLE.
# Run this command once per day until the subscription expires.
def pull_snapshots():
    print(f"[snapshots] {TODAY}")

    coins = get("/coins/list/v1", {"sort": "market_cap_rank", "limit": 0})
    if coins and "data" in coins:
        save_json(coins, f"snapshots/{TODAY}/coins_list.json")
        save_parquet(coins["data"], f"snapshots/{TODAY}/coins_list.parquet")
        print(f"  coins: {len(coins['data'])}")

    stocks = get("/stocks/list/v1", {"sort": "market_cap_rank", "limit": 0})
    if stocks and "data" in stocks:
        save_json(stocks, f"snapshots/{TODAY}/stocks_list.json")
        save_parquet(stocks["data"], f"snapshots/{TODAY}/stocks_list.parquet")
        print(f"  stocks: {len(stocks['data'])}")

    # 24h topic summaries (the previous-vs-current deltas you can't rebuild)
    topic_rows = []
    for t in WATCHLIST_TOPICS:
        s = get(f"/topic/{t}/v1")
        if s and "data" in s:
            save_json(s, f"snapshots/{TODAY}/topic_{t}.json")
            topic_rows.append(s["data"])
    save_parquet(topic_rows, f"snapshots/{TODAY}/topics_summary.parquet")
    print(f"  topic summaries: {len(topic_rows)}")


# ----------------------------- TIME-SERIES -----------------------------
# Historical data CAN be pulled retroactively, so this only needs to run once.
# Resumable: skips coins already on disk.
def coin_ids_to_pull():
    coins = get("/coins/list/v1", {"sort": "market_cap_rank", "limit": TOP_N})
    ids = []
    seen = set()
    if coins and "data" in coins:
        for c in coins["data"]:
            sym = (c.get("symbol") or "").upper()
            ids.append((c.get("id"), sym)); seen.add(sym)
    for sym in WATCHLIST_COINS:
        if sym.upper() not in seen:
            ids.append((sym, sym.upper()))   # symbol works as :coin too
    return ids


def pull_one_timeseries(coin_key, label, kind="coins"):
    relbase = f"timeseries/{kind}/{label}"
    if (OUT / f"{relbase}.parquet").exists() or (OUT / f"{relbase}.json").exists():
        return "skip"
    data = get(f"/{kind}/{coin_key}/time-series/v2",
               {"bucket": "day", "start": EARLIEST})
    if data and data.get("data"):
        save_json(data, f"{relbase}.json")
        save_parquet(data["data"], f"{relbase}.parquet")
        return f"ok {len(data['data'])}"
    return "empty"


def pull_timeseries():
    ids = coin_ids_to_pull()
    print(f"[timeseries] {len(ids)} coins")
    for i, (cid, sym) in enumerate(ids, 1):
        res = pull_one_timeseries(cid, sym, "coins")
        print(f"  {i}/{len(ids)} {sym}: {res}")

    for s in WATCHLIST_STOCKS:
        print(f"  stock {s}: {pull_one_timeseries(s, s, 'stocks')}")

    print(f"[topic timeseries] {len(WATCHLIST_TOPICS)} topics")
    for t in WATCHLIST_TOPICS:
        relbase = f"timeseries/topics/{t}"
        if (OUT / f"{relbase}.parquet").exists():
            print(f"  {t}: skip"); continue
        d = get(f"/topic/{t}/time-series/v1", {"bucket": "day", "start": EARLIEST})
        if d and d.get("data"):
            save_json(d, f"{relbase}.json")
            save_parquet(d["data"], f"{relbase}.parquet")
            print(f"  {t}: ok {len(d['data'])}")
        else:
            print(f"  {t}: empty")


# ----------------------------- CREATORS -----------------------------
def pull_creators():
    print("[creators]")
    lst = get("/creators/list/v1", {"sort": "interactions_24h", "limit": 1000})
    if lst and "data" in lst:
        save_json(lst, f"creators/{TODAY}_list.json")
        save_parquet(lst["data"], f"creators/{TODAY}_list.parquet")
        print(f"  creators listed: {len(lst['data'])}")


# ----------------------------- MAIN -----------------------------
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    t0 = time.time()
    if cmd in ("snapshots", "all"):  pull_snapshots()
    if cmd in ("timeseries", "all"): pull_timeseries()
    if cmd in ("creators", "all"):   pull_creators()
    print(f"done in {(time.time()-t0)/60:.1f} min  ->  {OUT.resolve()}")
