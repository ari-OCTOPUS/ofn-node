# گزارشِ پاک‌سازیِ تکراری‌ها — پروژه‌ی Crypto Research
**تاریخ:** ۱۵ ژوئن ۲۰۲۶ · **روش:** مقایسه‌ی md5 (نه فقط نام/سایز)

## خلاصه‌ی نتیجه
| | تعداد | حجم |
|---|---|---|
| ورودی (قبل) | ۱۵ فایل (۱۳ آپلود + ۲ در پوشه‌ی پروژه) | ~۷۵MB |
| **مجموعه‌ی فعّالِ تمیز (بعد)** | **۱۱ فایل** | ~۶۵MB |
| آرشیو (اجرای تکراری، حذف‌نشده) | ۳ فایل | ~۳.۸MB |
| حذفِ قطعی (کپیِ بایت‌به‌بایت) | ۲ فایل | ~۶.۱MB |

**قانونِ تصمیم:** فقط فایل‌هایی که md5شان *دقیقاً* یکی بود «حذفِ قطعی» شدند. فایل‌هایی که «اجرای دوباره‌ی همان داده با چند ساعت فاصله» بودند **آرشیو** شدند، نه حذف — چون بایت‌به‌بایت یکی نیستند و ممکن است بعداً به‌عنوان نقطه‌ی زمانی به دردت بخورند.

---

## ۱) حذفِ قطعی — کپیِ بایت‌به‌بایت (md5 یکسان)
این دو فایلِ پوشه‌ی پروژه دقیقاً همان بایت‌های دو فایلِ دیگر هستند. نگه‌داشتنشان صرفاً اشغالِ فضاست.

| فایلِ تکراری (حذف) | md5 | نسخه‌ی یکسان که می‌ماند |
|---|---|---|
| `cryptoquant_multi_20260614202011.csv` | `90dc82…696c14` | `cryptoquant_multi_2026-06-14-20-20-11.csv` ✅ |
| `lunarcrush_20260615084231.csv` | `ff5ff0…1dc7d9` | (نسخه‌ی ۰۸:۴۲ — که خودش هم در آرشیو است؛ زیر ↓) |

---

## ۲) آرشیو — اجرای دوباره/نازل‌تر (انتقال، نه حذف)
دیتای ۱۵ ژوئنِ LunarCrush دو بار با ~۲ ساعت فاصله گرفته شده و هر دو بار `coins=0` بوده (یعنی فقط ترندِ عمومی، نه سیگنالِ کوین). من **اجرای کاملِ ۰۶:۲۰** را نگه داشتم (چون خام + CSV + پرامپتش از یک pull است و با هم می‌خوانند) و **اجرای ناقصِ ۰۸:۴۲** را آرشیو کردم.

| فایلِ آرشیو‌شده | دلیل | جایگزینِ فعّال |
|---|---|---|
| `lunarcrush_2026-06-15-08-42-31.csv` | اجرای ۲ ساعت بعدِ همان ترندها، بدون خامِ متناظر | `…06-20-22.csv` |
| `lunarcrush_ai_2026-06-15-08-42-35.md` | پرامپتِ همان اجرای ناقص | `…06-20-25.md` |
| `lunarcrush_analysis_2026-06-14-15-33-59.json` | قدیمی‌تر از دو فایلِ آنالیز (~۳۰ دقیقه) | `…16-05-03.json` |

> اگر برعکسش را ترجیح می‌دهی (نگه‌داشتنِ جدیدترین اسنپ‌شاتِ ۰۸:۴۲ به‌جای ۰۶:۲۰)، فقط بگو — یک خط تغییر است.

---

## ۳) مجموعه‌ی نهاییِ تمیز — ۱۱ فایلِ فعّال
| پوشه | فایل | نقش | یادداشت |
|---|---|---|---|
| `01_onchain_cryptoquant/raw` | `cryptoquant_…15-32-50.json` | خام | ۴۶۰+ کلید، ۳۶۵ روز |
| `…/tables` | `cryptoquant_multi_…20-20-11.csv` | جدولی | ۲۳۴ سکشن |
| `…/analysis` | `cryptoquant_analysis_…20-20-16.json` | سیگنال | امتیازِ هر دارایی |
| `…/analysis` | `cryptoquant_ai_prompt_…20-20-15.md` | پرامپت | — |
| `02_social_lunarcrush/coins` | ⭐ `lunarcrush_…16-04-57.json` | خام | **۱۰۰۰ کوین + جزئیات** — تنها دیتای کوینِ سالم |
| `…/coins` | ⭐ `lunarcrush_coins_…16-04-55.csv` | جدولی | ۱۰۰۰ کوین (Galaxy/AltRank/sentiment) |
| `…/analysis` | `lunarcrush_analysis_…16-05-03.json` | سیگنال | top buy/sell |
| `…/trends` | `lunarcrush_…06-20-24.json` | خام | ۵۳MB — ترندِ عمومی (coins=0)، ارزشِ کریپتویی کم |
| `…/trends` | `lunarcrush_…06-20-22.csv` | جدولی | topics/cats/creators |
| `…/trends` | `lunarcrush_ai_…06-20-25.md` | پرامپت | — |
| `03_watchlist_equities` | `etoro_screening_prompt_fa.md` | فریم‌ورک | تمپلیتِ dip-vs-falling-knife (بازسازی‌شده) |

---

## ۴) ساختارِ پوشه
```
crypto-research-clean/
├── 01_onchain_cryptoquant/   (raw · tables · analysis)
├── 02_social_lunarcrush/
│   ├── coins/    ⭐ تنها دیتای کوینِ سالم (۱۴ ژوئن ۱۶:۰۴)
│   ├── trends/   ترندِ عمومیِ ۱۵ ژوئن (coins=0)
│   └── analysis/
├── 03_watchlist_equities/    فریم‌ورکِ غربالگریِ سهام
├── _archive/                 اجراهای تکراری (حذف‌نشده)
└── CLEANUP_REPORT.md
```

---

## ۵) اسکریپتِ پاک‌سازی (برای اجرا روی سیستمِ خودت)
اگر همه‌ی ۱۵ فایل را در یک پوشه داری، این اسکریپت ساختارِ تمیز را می‌سازد و تکراری‌ها را به `_archive/` می‌برد.
**هیچ‌چیز را `rm` نمی‌کند** — امن است. بعد از مرور، خودت می‌توانی `_archive/` را پاک کنی.

```bash
#!/usr/bin/env bash
set -e
mkdir -p clean/{01_onchain_cryptoquant/{raw,tables,analysis},02_social_lunarcrush/{coins,trends,analysis},03_watchlist_equities,_archive/_exact_duplicates}

# --- keepers ---
cp cryptoquant_2026-06-14-15-32-50.json        clean/01_onchain_cryptoquant/raw/
cp cryptoquant_multi_2026-06-14-20-20-11.csv   clean/01_onchain_cryptoquant/tables/
cp cryptoquant_analysis_2026-06-14-20-20-16.json clean/01_onchain_cryptoquant/analysis/
cp cryptoquant_ai_prompt_2026-06-14-20-20-15.md  clean/01_onchain_cryptoquant/analysis/
cp lunarcrush_2026-06-14-16-04-57.json   clean/02_social_lunarcrush/coins/
cp lunarcrush_coins_2026-06-14-16-04-55.csv clean/02_social_lunarcrush/coins/
cp lunarcrush_analysis_2026-06-14-16-05-03.json clean/02_social_lunarcrush/analysis/
cp lunarcrush_2026-06-15-06-20-24.json  clean/02_social_lunarcrush/trends/
cp lunarcrush_2026-06-15-06-20-22.csv   clean/02_social_lunarcrush/trends/
cp lunarcrush_ai_2026-06-15-06-20-25.md clean/02_social_lunarcrush/trends/

# --- archive: near-duplicate re-runs ---
mv lunarcrush_2026-06-15-08-42-31.csv   clean/_archive/ 2>/dev/null || true
mv lunarcrush_ai_2026-06-15-08-42-35.md clean/_archive/ 2>/dev/null || true
mv lunarcrush_analysis_2026-06-14-15-33-59.json clean/_archive/ 2>/dev/null || true

# --- archive: exact byte-duplicates (project-folder copies, no dashes in name) ---
mv cryptoquant_multi_20260614202011.csv clean/_archive/_exact_duplicates/ 2>/dev/null || true
mv lunarcrush_20260615084231.csv        clean/_archive/_exact_duplicates/ 2>/dev/null || true

echo "Done. Active set in clean/ , redundancies in clean/_archive/"
```

---

## ۶) نکته‌های مهم (فراتر از پاک‌سازی)
- **دیتای کوینِ LunarCrush فقط در اجرای ۱۴ ژوئن ۱۶:۰۴ سالم است** (پلن Individual، ۱۰۰۰ کوین). اجراهای ۱۵ ژوئن خطای `402` خوردند → `coins=0`. هر تحلیلِ کوینی باید روی پوشه‌ی `coins/` بنشیند، نه `trends/`.
- **CryptoQuant فقط BTC و ETH دیتای عمیق دارد** (پوشش ~۱۱٪؛ ۱۷ از ۲۱ دارایی خالی). دارایی‌های «NEUTRAL / Confidence 0%» یعنی «دیتا نیست».
- **قدمِ بعدیِ اختیاری:** اگر بخواهی، فایلِ ۵۳مگیِ ترند (`…06-20-24.json`) و کلِ پوشه‌ی `trends/` را هم می‌شود آرشیو کرد، چون ارزشِ کریپتویی‌اش نزدیکِ صفر است. این دیگر «پاک‌سازیِ کیفیت» است، نه «تکراری».
- **برای آینده:** این فایل‌ها همه اسنپ‌شاتِ ۱۴–۱۵ ژوئن‌اند. اگر می‌خواهی آرشیوِ زمان‌دار جمع کنی، پوشه‌ها را با تاریخ نام‌گذاری کن (مثلاً `coins/2026-06-14/`).
