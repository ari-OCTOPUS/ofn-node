#!/usr/bin/env bash
# =============================================================================
# 01_install_fullnode.sh — Operation Piggy Bank 2026
# Purpose : Download and configure Hacash full node on Node 1 (ARM64)
# Run on  : Node 1 (the Full Node board) — as root
# Usage   : bash 01_install_fullnode.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.env"

echo "=============================================="
echo " Operation Piggy Bank 2026 — Full Node Setup"
echo " Node 1 | Role: ${NODE_1_ROLE}"
echo "=============================================="

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] Run as root." >&2; exit 1
fi

# ---------- Download Hacash fullnode binary ----------------------------------
echo "[STEP 1] Downloading Hacash fullnode ${HACASH_VERSION} (${HACASH_ARCH})..."
DOWNLOAD_URL="${GITHUB_RELEASE_BASE}/${FULLNODE_BINARY}"
DEST_BIN="${INSTALL_DIR}/hacash_fullnode"

echo "  URL: ${DOWNLOAD_URL}"
curl -fsSL --retry 3 --retry-delay 5 \
    -o "${DEST_BIN}" \
    "${DOWNLOAD_URL}" || {
    echo "[ERROR] Download failed. Check URL or network connection." >&2
    echo "        Verify latest release at: https://github.com/hacash/fullnode/releases" >&2
    exit 1
}
chmod +x "${DEST_BIN}"
echo "[STEP 1] Binary downloaded and made executable."

# ---------- Write hacash.config.ini for full node ----------------------------
echo "[STEP 2] Writing hacash.config.ini..."
cat > "${CONFIG_INI}" <<EOF
; Hacash Full Node Configuration
; Operation Piggy Bank 2026 — Node 1 (Full Node)
; Generated: $(date -u '+%Y-%m-%d %H:%M:%S UTC')
; Hacash version: ${HACASH_VERSION}

[node]
; Data directory for blockchain storage
data_dir = ${DATA_DIR}

; P2P listen port
listen_port = ${FULLNODE_P2P_PORT}

; Boot nodes (official Hacash network bootstrap nodes — do not remove)
boot_nodes = 182.92.163.225:3337,47.244.26.14:3337

; Not-find-nodes: uncomment ONLY during hard fork recovery
; not_find_nodes = true
; not_accept_nodes = true

[server]
; RPC/API port — miners connect here
listen_port = ${FULLNODE_API_PORT}

[miner]
; HAC block mining: enabled on fullnode so Node 1 also mines
enable = true

; Cold wallet reward address (from MoneyNex)
reward = ${HAC_REWARD_ADDRESS}

; HACD diamond mining: disabled on fullnode (requires separate setup)
; enable_diamond = false
EOF
echo "[STEP 2] hacash.config.ini written."

# ---------- Create systemd service -------------------------------------------
echo "[STEP 3] Creating systemd service: ${SYSTEMD_FULLNODE_UNIT}..."
cat > "/etc/systemd/system/${SYSTEMD_FULLNODE_UNIT}.service" <<EOF
[Unit]
Description=Hacash Full Node — Operation Piggy Bank 2026
# Start after network is up — no hard dependency on other boards
After=network-online.target
Wants=network-online.target
# If it crashes, systemd restarts it automatically
StartLimitIntervalSec=0

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=${DEST_BIN} ${CONFIG_INI}

# --- Auto-restart policy (survives reboots and crashes) ---
Restart=always
RestartSec=15
# No limit on restart attempts — mine forever
StartLimitBurst=0

# --- Systemd watchdog (kills and restarts if process hangs silently) ---
# Requires the binary to call sd_notify — if not supported, comment this out
# WatchdogSec=120

# --- Logging ---
StandardOutput=append:${LOG_DIR}/fullnode.log
StandardError=append:${LOG_DIR}/fullnode.err

# --- Resource limits ---
LimitNOFILE=65535
OOMScoreAdjust=100

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SYSTEMD_FULLNODE_UNIT}" --quiet
systemctl start  "${SYSTEMD_FULLNODE_UNIT}"
sleep 3

# ---------- Verify service started -------------------------------------------
if systemctl is-active --quiet "${SYSTEMD_FULLNODE_UNIT}"; then
    echo "[STEP 3] Service ${SYSTEMD_FULLNODE_UNIT} is running."
else
    echo "[WARNING] Service may not have started. Check logs:" >&2
    echo "          journalctl -u ${SYSTEMD_FULLNODE_UNIT} -n 20" >&2
fi

echo ""
echo "=============================================="
echo " Full Node setup complete!"
echo " Data dir  : ${DATA_DIR}"
echo " API port  : ${FULLNODE_API_PORT}"
echo " P2P port  : ${FULLNODE_P2P_PORT}"
echo " Logs      : ${LOG_DIR}/fullnode.log"
echo "=============================================="
echo ""
echo "[NOTE] Block sync will take several hours. Monitor with:"
echo "       journalctl -fu ${SYSTEMD_FULLNODE_UNIT}"
echo ""
echo "[NEXT] Wait for sync, then run 02_install_miner.sh on Nodes 2-4"
