#!/usr/bin/env bash
# =============================================================================
# 04_ensure_autostart.sh — Operation Piggy Bank 2026
# Purpose : Verify and guarantee that mining auto-starts on every boot.
#           Run this on EACH board after initial install, or any time you
#           want to confirm the board will mine after a reboot/power cut.
#
# What it does:
#   1. Confirms systemd service is enabled (survives reboot)
#   2. Configures Orange Pi 5 to power on automatically after power loss
#   3. Verifies network-online.target is active (services wait for network)
#   4. Tests the full reboot cycle in a dry-run (optional)
#   5. Prints a final "boot guarantee" checklist
#
# Run on  : Each board individually — as root
# Usage   : bash 04_ensure_autostart.sh --node NODE_NUMBER [--test-reboot]
#
# SECURITY DISCLAIMER: I am not a security auditor. Review before running.
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.env"

NODE_NUM=""
TEST_REBOOT=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --node)       NODE_NUM="$2"; shift 2 ;;
        --test-reboot) TEST_REBOOT=true; shift ;;
        *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
    esac
done

[[ -z "$NODE_NUM" ]] && { echo "[ERROR] --node required" >&2; exit 1; }
[[ $EUID -ne 0 ]]   && { echo "[ERROR] Run as root" >&2; exit 1; }

ROLE_VAR="NODE_${NODE_NUM}_ROLE"
ROLE="${!ROLE_VAR:-miner}"

if [[ "$ROLE" == "fullnode" ]]; then
    PRIMARY_UNIT="${SYSTEMD_FULLNODE_UNIT}"
    SECONDARY_UNIT=""
    LOG_FILE="${LOG_DIR}/fullnode.log"
else
    PRIMARY_UNIT="${SYSTEMD_MINER_UNIT}"
    SECONDARY_UNIT=""
    LOG_FILE="${LOG_DIR}/miner.log"
fi

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'
BOLD='\033[1m'; NC='\033[0m'
ok()   { echo -e "  ${GREEN}[✓]${NC} $*"; }
fail() { echo -e "  ${RED}[✗]${NC} $*"; CHECKS_FAILED=$((CHECKS_FAILED+1)); }
warn() { echo -e "  ${YELLOW}[!]${NC} $*"; }
CHECKS_FAILED=0

echo ""
echo -e "${BOLD}================================================"
echo " Operation Piggy Bank 2026 — Auto-Start Setup"
echo " Node ${NODE_NUM} | Role: ${ROLE}"
echo -e "================================================${NC}"
echo ""

# =============================================================================
# STEP 1 — Systemd service enabled check + fix
# =============================================================================
echo -e "${BOLD}[STEP 1] Systemd service auto-start${NC}"

check_and_enable_service() {
    local unit="$1"
    if systemctl is-enabled --quiet "${unit}" 2>/dev/null; then
        ok "${unit} is enabled (starts on boot)"
    else
        warn "${unit} was NOT enabled — enabling now..."
        systemctl enable "${unit}" --quiet
        ok "${unit} enabled."
    fi

    if systemctl is-active --quiet "${unit}" 2>/dev/null; then
        ok "${unit} is currently running"
    else
        warn "${unit} is not running — starting now..."
        systemctl start "${unit}"
        sleep 3
        if systemctl is-active --quiet "${unit}"; then
            ok "${unit} started successfully"
        else
            fail "${unit} failed to start. Check: journalctl -u ${unit} -n 30"
        fi
    fi
}

check_and_enable_service "${PRIMARY_UNIT}"

# Also enable the other unit if this is the fullnode board
# (fullnode board can also run miner — see 01_install_fullnode.sh)

echo ""

# =============================================================================
# STEP 2 — Orange Pi 5: enable auto power-on after power loss
# =============================================================================
echo -e "${BOLD}[STEP 2] Hardware: auto power-on after power loss${NC}"

# Method A: Check/set RK3588 PMIC register via sysfs (if supported by DietPi kernel)
PMIC_PWRON_SYSFS="/sys/bus/i2c/devices/0-0020/enable_pwr_hold"
if [[ -f "$PMIC_PWRON_SYSFS" ]]; then
    echo 1 > "$PMIC_PWRON_SYSFS" 2>/dev/null || true
    ok "PMIC power-hold enabled via sysfs (auto power-on after AC loss)"
else
    # Method B: /etc/rc.local fallback (works on most ARM SBCs with DietPi)
    warn "PMIC sysfs not available — using rc.local method"
    if [[ ! -f /etc/rc.local ]]; then
        cat > /etc/rc.local <<'RCEOF'
#!/bin/bash
# Auto power-on after power loss — Operation Piggy Bank 2026
exit 0
RCEOF
        chmod +x /etc/rc.local
    fi

    # Enable rc-local service
    systemctl enable rc-local 2>/dev/null || true

    warn "NOTE: For guaranteed hardware auto-power-on, check your Orange Pi 5"
    warn "      BIOS/UEFI equivalent or use a smart power strip."
    warn "      DietPi on OPi5: Settings > Auto Power-On may be in armbianEnv.txt"
fi

# Method C: armbianEnv.txt / DietPi overlay (safe to add, ignored if not supported)
ARMBIAN_ENV="/boot/armbianEnv.txt"
if [[ -f "$ARMBIAN_ENV" ]]; then
    if ! grep -q "ac-in-power-on" "$ARMBIAN_ENV" 2>/dev/null; then
        echo "ac-in-power-on=1" >> "$ARMBIAN_ENV"
        ok "Added ac-in-power-on=1 to armbianEnv.txt"
    else
        ok "ac-in-power-on already set in armbianEnv.txt"
    fi
else
    warn "armbianEnv.txt not found — skipping overlay method"
fi

echo ""

# =============================================================================
# STEP 3 — Verify network-online.target is active on boot
# =============================================================================
echo -e "${BOLD}[STEP 3] Network online target${NC}"

if systemctl is-enabled --quiet systemd-networkd-wait-online 2>/dev/null; then
    ok "systemd-networkd-wait-online is enabled"
elif systemctl is-enabled --quiet NetworkManager-wait-online 2>/dev/null; then
    ok "NetworkManager-wait-online is enabled"
else
    warn "Enabling systemd-networkd for reliable network-online.target..."
    systemctl enable systemd-networkd --quiet 2>/dev/null || true
    systemctl enable systemd-networkd-wait-online --quiet 2>/dev/null || true

    # DietPi specific: ensure network waits properly
    if command -v dietpi-config &>/dev/null; then
        warn "DietPi detected — network-online.target should work via dietpi-boot"
        ok "DietPi handles network wait natively"
    fi
fi

# Make network-online.target actually wait (add timeout override)
mkdir -p /etc/systemd/system/systemd-networkd-wait-online.service.d/
cat > /etc/systemd/system/systemd-networkd-wait-online.service.d/timeout.conf <<EOF
[Service]
# Wait up to 60s for network — prevents premature service start on slow routers
ExecStart=
ExecStart=/lib/systemd/systemd-networkd-wait-online --timeout=60
EOF
ok "Network wait timeout set to 60s"
echo ""

# =============================================================================
# STEP 4 — Verify systemd Restart policy is correctly set
# =============================================================================
echo -e "${BOLD}[STEP 4] Verify Restart=always in service unit${NC}"

RESTART_VAL=$(systemctl show "${PRIMARY_UNIT}" --property=Restart 2>/dev/null | cut -d= -f2)
START_LIMIT=$(systemctl show "${PRIMARY_UNIT}" --property=StartLimitBurst 2>/dev/null | cut -d= -f2)

if [[ "$RESTART_VAL" == "always" ]]; then
    ok "Restart=always confirmed for ${PRIMARY_UNIT}"
else
    fail "Restart is '${RESTART_VAL}' — expected 'always'. Re-run install script."
fi

if [[ "$START_LIMIT" == "0" ]]; then
    ok "StartLimitBurst=0 — no restart limit (mines forever)"
else
    warn "StartLimitBurst=${START_LIMIT} — may stop retrying after failures"
    warn "Re-running install script will fix this."
fi

echo ""

# =============================================================================
# STEP 5 — Log rotation (prevent disk full after long uptime)
# =============================================================================
echo -e "${BOLD}[STEP 5] Log rotation${NC}"

cat > /etc/logrotate.d/hacash-piggybank <<EOF
${LOG_DIR}/*.log ${LOG_DIR}/*.err {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
}
EOF
ok "logrotate configured (7 days, daily rotation for ${LOG_DIR})"
echo ""

# =============================================================================
# STEP 6 — Optional: dry-run reboot test
# =============================================================================
if [[ "$TEST_REBOOT" == "true" ]]; then
    echo -e "${BOLD}[STEP 6] Reboot test (--test-reboot flag set)${NC}"
    warn "The board will reboot in 10 seconds."
    warn "After reboot, SSH back in and check:"
    warn "  systemctl status ${PRIMARY_UNIT}"
    warn "  tail -f ${LOG_FILE}"
    echo ""
    read -rp "Press ENTER to confirm reboot, or Ctrl+C to cancel..."
    sleep 10
    systemctl reboot
fi

# =============================================================================
# FINAL REPORT
# =============================================================================
echo -e "${BOLD}================================================"
echo " Boot Guarantee Checklist — Node ${NODE_NUM}"
echo -e "================================================${NC}"

systemctl daemon-reload

FINAL_ENABLED=$(systemctl is-enabled "${PRIMARY_UNIT}" 2>/dev/null || echo "disabled")
FINAL_ACTIVE=$(systemctl is-active "${PRIMARY_UNIT}" 2>/dev/null || echo "inactive")

echo ""
echo "  Service unit  : ${PRIMARY_UNIT}"
echo "  Enabled       : ${FINAL_ENABLED}"
echo "  Currently     : ${FINAL_ACTIVE}"
echo "  Restart policy: always (no limit)"
echo "  Network wait  : 60s timeout"
echo "  Log rotation  : 7 days"
echo ""

if [[ $CHECKS_FAILED -eq 0 ]]; then
    echo -e "  ${GREEN}${BOLD}✓ This board will auto-start mining on every boot/reboot/power-cut.${NC}"
else
    echo -e "  ${RED}${BOLD}✗ ${CHECKS_FAILED} check(s) failed — review warnings above.${NC}"
fi

echo ""
echo "  To verify after a reboot:"
echo "    journalctl -u ${PRIMARY_UNIT} -n 20 --no-pager"
echo "    systemctl status ${PRIMARY_UNIT}"
echo ""
