#!/usr/bin/env bash
# =============================================================================
# 00_base_hardening.sh — Operation Piggy Bank 2026
# Purpose : Harden a single Orange Pi 5 (DietPi) board.
#           Run this on EACH board individually via SSH before any other step.
# Usage   : bash 00_base_hardening.sh [--node NODE_NUMBER]
# Example : bash 00_base_hardening.sh --node 1
#
# SECURITY DISCLAIMER: I am not a security auditor.
#   Review this script before running in production.
#   This script WILL change SSH config. It will NOT disable password auth
#   until it verifies your key-based login works.
# =============================================================================

set -euo pipefail

# ---------- Source central config -------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config.env"
if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[ERROR] config.env not found at: $CONFIG_FILE" >&2
    exit 1
fi
source "$CONFIG_FILE"

# ---------- Parse arguments --------------------------------------------------
NODE_NUM=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --node) NODE_NUM="$2"; shift 2 ;;
        *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
    esac
done

if [[ -z "$NODE_NUM" ]]; then
    echo "[ERROR] --node argument is required (e.g. --node 1)" >&2
    exit 1
fi

echo "=============================================="
echo " Operation Piggy Bank 2026 — Hardening"
echo " Target board: Node ${NODE_NUM}"
echo "=============================================="

# ---------- Pre-flight: verify we are running as root ------------------------
if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] This script must run as root on the target board." >&2
    exit 1
fi

# ---------- Pre-flight: SSH key must exist on this board BEFORE we lock ------
PRE_FLIGHT_KEY_CHECK() {
    echo "[PRE-FLIGHT] Checking for authorized SSH public keys..."
    AUTH_KEYS_FILE="${HOME}/.ssh/authorized_keys"
    if [[ ! -f "$AUTH_KEYS_FILE" ]]; then
        echo "[ERROR] ${AUTH_KEYS_FILE} does not exist." >&2
        echo "        Copy your public key first:" >&2
        echo "        ssh-copy-id -i ${SSH_KEY_PATH}.pub ${SSH_USER}@<board-ip>" >&2
        echo "        Then re-run this script." >&2
        exit 1
    fi
    KEY_COUNT=$(grep -c 'ssh-' "$AUTH_KEYS_FILE" 2>/dev/null || true)
    if [[ "$KEY_COUNT" -lt 1 ]]; then
        echo "[ERROR] No SSH public keys found in ${AUTH_KEYS_FILE}." >&2
        echo "        Add your key before disabling password auth." >&2
        exit 1
    fi
    echo "[PRE-FLIGHT] OK — Found ${KEY_COUNT} authorized key(s). Safe to harden SSH."
}
PRE_FLIGHT_KEY_CHECK

# ---------- System update ----------------------------------------------------
echo "[STEP 1] Updating system packages..."
apt-get update -qq
apt-get upgrade -y -qq
apt-get install -y -qq ufw fail2ban curl wget jq unattended-upgrades

# ---------- SSH hardening ----------------------------------------------------
echo "[STEP 2] Hardening SSH (port: ${SSH_PORT})..."
SSHD_CONFIG="/etc/ssh/sshd_config"
cp "${SSHD_CONFIG}" "${SSHD_CONFIG}.bak.$(date +%Y%m%d%H%M%S)"

# Apply SSH settings safely using sed + append
apply_sshd_setting() {
    local key="$1"
    local value="$2"
    if grep -qE "^#?${key}" "$SSHD_CONFIG"; then
        sed -i "s|^#\?${key}.*|${key} ${value}|g" "$SSHD_CONFIG"
    else
        echo "${key} ${value}" >> "$SSHD_CONFIG"
    fi
}

apply_sshd_setting "Port"                    "${SSH_PORT}"
apply_sshd_setting "PermitRootLogin"         "prohibit-password"
apply_sshd_setting "PasswordAuthentication"  "no"
apply_sshd_setting "PubkeyAuthentication"    "yes"
apply_sshd_setting "AuthorizedKeysFile"      ".ssh/authorized_keys"
apply_sshd_setting "X11Forwarding"           "no"
apply_sshd_setting "AllowAgentForwarding"    "no"
apply_sshd_setting "MaxAuthTries"            "3"
apply_sshd_setting "LoginGraceTime"          "30"
apply_sshd_setting "ClientAliveInterval"     "300"
apply_sshd_setting "ClientAliveCountMax"     "2"

# Validate sshd config before restarting
sshd -t || {
    echo "[ERROR] sshd config test failed. Restoring backup..." >&2
    cp "${SSHD_CONFIG}.bak."* "$SSHD_CONFIG" 2>/dev/null || true
    exit 1
}
systemctl restart sshd
echo "[STEP 2] SSH hardened."

# ---------- Firewall (UFW) ---------------------------------------------------
if [[ "$ENABLE_UFW" == "true" ]]; then
    echo "[STEP 3] Configuring UFW firewall..."
    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow from "${ALLOW_SSH_FROM}" to any port "${SSH_PORT}" proto tcp comment "SSH"
    ufw allow "${FULLNODE_P2P_PORT}/tcp"  comment "Hacash P2P"
    ufw allow "${FULLNODE_API_PORT}/tcp"  comment "Hacash API (miners)"
    ufw --force enable
    echo "[STEP 3] UFW configured."
else
    echo "[STEP 3] UFW skipped (ENABLE_UFW=false in config.env)"
fi

# ---------- Fail2ban ---------------------------------------------------------
echo "[STEP 4] Configuring fail2ban..."
cat > /etc/fail2ban/jail.local <<EOF
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5

[sshd]
enabled  = true
port     = ${SSH_PORT}
filter   = sshd
logpath  = /var/log/auth.log
maxretry = 3
EOF
systemctl enable fail2ban --quiet
systemctl restart fail2ban
echo "[STEP 4] fail2ban configured."

# ---------- System optimizations for mining ----------------------------------
echo "[STEP 5] Applying system optimizations..."

# Increase file descriptor limits
cat > /etc/security/limits.d/99-hacash.conf <<EOF
# Hacash mining — Operation Piggy Bank 2026
root soft nofile 65535
root hard nofile 65535
* soft nofile 65535
* hard nofile 65535
EOF

# Kernel networking tweaks for P2P
cat > /etc/sysctl.d/99-hacash.conf <<EOF
# Hacash P2P optimization
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
net.core.somaxconn = 1024
vm.swappiness = 10
EOF
sysctl --system -q
echo "[STEP 5] Optimizations applied."

# ---------- Create install directory -----------------------------------------
echo "[STEP 6] Creating directory structure..."
mkdir -p "${INSTALL_DIR}" "${DATA_DIR}" "${LOG_DIR}"
chmod 750 "${INSTALL_DIR}"
echo "[STEP 6] Directories created."

# ---------- Set hostname ------------------------------------------------------
NEW_HOSTNAME="piggybank-node${NODE_NUM}"
hostnamectl set-hostname "${NEW_HOSTNAME}"
echo "127.0.1.1  ${NEW_HOSTNAME}" >> /etc/hosts
echo "[INFO] Hostname set to: ${NEW_HOSTNAME}"

echo ""
echo "=============================================="
echo " Hardening complete for Node ${NODE_NUM}"
echo " Hostname: ${NEW_HOSTNAME}"
echo " SSH port: ${SSH_PORT}"
echo " Install dir: ${INSTALL_DIR}"
echo "=============================================="
echo ""
echo "[NEXT] Run 01_install_fullnode.sh on Node 1 (Full Node board)"
echo "       Run 02_install_miner.sh on Nodes 2-4 (Miner boards)"
