#!/usr/bin/env bash
# =============================================================================
# 02_install_miner.sh — Operation Piggy Bank 2026
# Purpose : Download and configure Hacash poworker on a miner board (ARM64)
# Run on  : Each miner board (Node 2, 3, 4, 5, 6) — as root
# Usage   : bash 02_install_miner.sh --node NODE_NUMBER
# Example : bash 02_install_miner.sh --node 2
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.env"

# ---------- Parse arguments --------------------------------------------------
NODE_NUM=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --node) NODE_NUM="$2"; shift 2 ;;
        *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
    esac
done

if [[ -z "$NODE_NUM" ]]; then
    echo "[ERROR] --node argument required. Example: --node 2" >&2
    exit 1
fi

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] Run as root." >&2; exit 1
fi

echo "=============================================="
echo " Operation Piggy Bank 2026 — Miner Setup"
echo " Node ${NODE_NUM} | Role: miner (poworker)"
echo " Threads: ${MINER_THREADS} | Fullnode: ${NODE_1_IP}:${FULLNODE_API_PORT}"
echo "=============================================="

# ---------- Download poworker binary -----------------------------------------
echo "[STEP 1] Downloading Hacash poworker ${HACASH_VERSION} (${HACASH_ARCH})..."
DOWNLOAD_URL="${GITHUB_RELEASE_BASE}/${POWORKER_BINARY}"
DEST_BIN="${INSTALL_DIR}/hacash_poworker"

echo "  URL: ${DOWNLOAD_URL}"
curl -fsSL --retry 3 --retry-delay 5 \
    -o "${DEST_BIN}" \
    "${DOWNLOAD_URL}" || {
    echo "[ERROR] Download failed. Check URL or network connection." >&2
    echo "        Verify latest release at: https://github.com/hacash/fullnode/releases" >&2
    exit 1
}
chmod +x "${DEST_BIN}"
echo "[STEP 1] poworker binary downloaded."

# ---------- Write poworker.config.ini ----------------------------------------
echo "[STEP 2] Writing poworker.config.ini..."
cat > "${POWORKER_INI}" <<EOF
; Hacash poworker Configuration
; Operation Piggy Bank 2026 — Node ${NODE_NUM} (Miner)
; Generated: $(date -u '+%Y-%m-%d %H:%M:%S UTC')

[config]
; Full node API endpoint (Node 1 IP and API port)
connect = ${NODE_1_IP}:${FULLNODE_API_PORT}

; Number of mining threads (Orange Pi 5 has 8 cores — reserve 1 for OS)
supervene = ${MINER_THREADS}

; Optional: Override reward address per miner (defaults to fullnode reward)
; reward = ${HAC_REWARD_ADDRESS}
EOF
echo "[STEP 2] poworker.config.ini written."

# ---------- Create systemd service -------------------------------------------
echo "[STEP 3] Creating systemd service: ${SYSTEMD_MINER_UNIT}..."
cat > "/etc/systemd/system/${SYSTEMD_MINER_UNIT}.service" <<EOF
[Unit]
Description=Hacash Miner (poworker) — Operation Piggy Bank 2026 Node ${NODE_NUM}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=${DEST_BIN} ${POWORKER_INI}
Restart=always
RestartSec=15
StandardOutput=append:${LOG_DIR}/miner.log
StandardError=append:${LOG_DIR}/miner.err
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SYSTEMD_MINER_UNIT}" --quiet
systemctl start  "${SYSTEMD_MINER_UNIT}"
sleep 3

# ---------- Verify service ---------------------------------------------------
if systemctl is-active --quiet "${SYSTEMD_MINER_UNIT}"; then
    echo "[STEP 3] Service ${SYSTEMD_MINER_UNIT} is running on Node ${NODE_NUM}."
else
    echo "[WARNING] Service may not have started. Check logs:" >&2
    echo "          journalctl -u ${SYSTEMD_MINER_UNIT} -n 20" >&2
fi

echo ""
echo "=============================================="
echo " Miner setup complete — Node ${NODE_NUM}"
echo " Connecting to fullnode: ${NODE_1_IP}:${FULLNODE_API_PORT}"
echo " Mining threads: ${MINER_THREADS}"
echo " Logs: ${LOG_DIR}/miner.log"
echo "=============================================="
echo ""
echo "[MONITOR] Watch live mining output:"
echo "          journalctl -fu ${SYSTEMD_MINER_UNIT}"
echo "[SUCCESS] Look for '[MINING SUCCESS]' in the log."
