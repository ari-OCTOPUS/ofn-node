"""
mining_data.py — real network_hashrate + block_reward for the ENERGY edge
=========================================================================
energy_funnel._fetch_hashrate() and _extract_block_reward() currently return
MISSING/None (CoinGecko does not expose these), so ENERGY can never fire.
This adapter sources them per-coin from that coin's own block explorer, which
is the only reliable source for small PoW chains.

Contract: returns FieldValue-shaped dicts {value,status,source} — the same
shape edge_classifier._get_fv() already consumes. When an explorer is unknown
or unreachable, returns MISSING → ENERGY stays NO_EDGE (E-0 honesty, correct).

Populate EXPLORERS as target yespower coins are chosen. Endpoints follow the
common iquidus/blockbook explorer API shape; override per coin as needed.
"""
import requests

TIMEOUT = 10

# coin_id (CoinGecko) → explorer API base. Extend as targets are picked.
EXPLORERS: dict[str, str] = {
    # "sugarchain": "https://explorer.sugarchain.org/api",
    # "myriadcoin": "https://myriad.social/api",
}


def _fv(value, status, source):
    return {"value": value, "status": status, "source": source}


def fetch_network_hashrate(coin_id: str) -> dict:
    """H/s from the coin's explorer (getnetworkhashps), else MISSING."""
    base = EXPLORERS.get(coin_id)
    if not base:
        return _fv(None, "MISSING", "no-explorer-registered")
    try:
        r = requests.get(f"{base}/getnetworkhashps", timeout=TIMEOUT)
        r.raise_for_status()
        return _fv(float(r.text.strip()), "MEASURED", "explorer")
    except Exception as e:
        return _fv(None, "MISSING", f"explorer-error:{type(e).__name__}")


def fetch_block_reward(coin_id: str) -> dict:
    """block_reward (coins) + blocks_per_day from explorer, else MISSING."""
    base = EXPLORERS.get(coin_id)
    if not base:
        return {"block_reward_coins": None, "blocks_per_day": None,
                "status": "MISSING", "source": "no-explorer-registered"}
    try:
        reward = float(requests.get(f"{base}/getblockreward", timeout=TIMEOUT).text.strip())
        # blocks/day = 86400 / target block time (sec). Explorer exposes it or infer.
        bt = requests.get(f"{base}/getblocktime", timeout=TIMEOUT)
        block_time_s = float(bt.text.strip()) if bt.ok else None
        bpd = round(86400 / block_time_s) if block_time_s else None
        return {"block_reward_coins": reward, "blocks_per_day": bpd,
                "status": "MEASURED", "source": "explorer"}
    except Exception as e:
        return {"block_reward_coins": None, "blocks_per_day": None,
                "status": "MISSING", "source": f"explorer-error:{type(e).__name__}"}


def enrich_energy_inputs(coin: dict) -> dict:
    """
    Annotate a coin dict (from EnergyFunnel) with real mining inputs.
    Safe no-op MISSING when explorer unknown → ENERGY correctly stays NO_EDGE.
    Call in main.py Step 1.5, right after EnergyFunnel.find_candidates().
    """
    cid = coin.get("id")
    if not cid:
        return coin
    coin["network_hashrate"] = fetch_network_hashrate(cid)
    br = fetch_block_reward(cid)
    coin["block_reward_coins"] = br["block_reward_coins"]
    coin["blocks_per_day"]     = br["blocks_per_day"]
    return coin
