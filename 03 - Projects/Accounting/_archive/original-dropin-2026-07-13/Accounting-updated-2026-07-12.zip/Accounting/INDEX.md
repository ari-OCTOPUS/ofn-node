---
type: moc
project: "[[03 - Projects/Accounting/PROJECT]]"
status: active
tags: [accounting]
created: 2026-07-04
updated: 2026-07-04
---

# INDEX — MOC پروژه Accounting

> کیت مغز پروژه ([[_memory/LIVING-BRAIN-BLUEPRINT|بلوپرینت]]) — 2026-07-04.

## هسته
- [[03 - Projects/Accounting/PROJECT|PROJECT]] — شناسنامه + Active Context
- [[03 - Projects/Accounting/DecisionLog|DecisionLog]] · [[03 - Projects/Accounting/OpenQuestions|OpenQuestions]]
- [[03 - Projects/Accounting/Accounting|Accounting]] — لاگ تلگرام

## اسناد
- [[03 - Projects/Accounting/docs/Ecosystem-Rollout-Plan|Ecosystem-Rollout-Plan]] — پل به [[06 - Architecture Maps/ECOSYSTEM|ECOSYSTEM]]
- [[03 - Projects/Accounting/Report - Accounting - Tax Map FY2025-26|Report — Tax Map FY2025-26]]
- [[03 - Projects/Accounting/docs/Tax-and-Loan-Guide|Tax-and-Loan-Guide]]
- [[03 - Projects/Accounting/docs/Agent-Architecture-and-Research-Prompt|Agent-Architecture-and-Research-Prompt]]
- `app/README.md` · `app/PROJECT_STRUCTURE.pdf`

## خروجی‌های جلسهٔ 2026-07-12 (Cowork — همه draft/[Unverified])
- `reports/STATUS-GAP-REPORT-2026-07-12.md` — گزارش وضعیت + دلتای مستندات↔واقعیت
- `reports/importer-validation-2026-07-12.md` — راستی‌آزمایی importer (ACC-V9)
- `drafts/associates-subledger-DRAFT-2026-07-12.md` — sub-ledger پیش‌نویس AUG–NOV 2024
- `drafts/receipts-pilot-2026-07-12.md` — نتیجهٔ پایلوت ACC-V8 (صفر رسید واقعی)
- `flags/compliance-flags-2026-07-12.md` — پرچم‌های انطباق برای حسابدار
- `drafts/ledger-extract/*.csv` + `drafts/importer-run/*.json` — دیتای استخراجی (PII، داخل پوشه بماند)

## غیر-نوت (بک‌لاگ قاعدهٔ ۴ — جابه‌جایی بعد از گیت)
- `app/` (کد بات و داشبوردها) · `importer/` · `data/حساب کتاب/` · `photos/` · `data/receipts/_not-receipts-quarantine-2026-07-12/` (⚠️ رسید نیستند — ACC-V11)
