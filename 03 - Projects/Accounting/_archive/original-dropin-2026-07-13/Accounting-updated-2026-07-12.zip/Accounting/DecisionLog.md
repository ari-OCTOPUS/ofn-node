---
type: log
project: "[[03 - Projects/Accounting/PROJECT]]"
status: active
tags: [accounting, decisions]
created: 2026-07-04
updated: 2026-07-04
---

# DecisionLog — Accounting

> تصمیم + دلیل. seed اولیه از [[03 - Projects/Accounting/PROJECT|PROJECT]] و DECISIONS معماری — 2026-07-04.

**D3 — ساختار Pty Ltd.** برای قراردادهای بزرگ‌تر و دفاتر audit-ready؛ tenant #1 سیستم architect (ترتیب D-26: Accounting → Lead → Mining).
**قاعدهٔ مشاوره.** هیچ ایجنتی مشاوره مالیاتی نمی‌دهد؛ همهٔ قواعد `[Unverified — accountant to confirm]` تا تأیید حسابدار رسمی.
**قاعدهٔ lodge.** ایجنت هرگز به ATO/ASIC ارسال نمی‌کند — verdict انسانی برای هر ثبت نهایی و هر پرداخت.
**گردش‌کار رسید.** رسید → Inbox/تلگرام → draft دسته‌بندی ایجنت → تأیید انسان → بایگانی. نگهداری ۵ سال ATO / ۷ سال اسناد شرکت (s 286).

## 2026-07-12 — جلسهٔ Cowork (verdictهای مالک + اجرا)

**Verdict مالک — دستور کار چهارگانه.** گزارش وضعیت + تست importer + پایلوت رسید (ACC-V8→approved) + استخراج xlsx؛ خروجی zip کامل.
**Verdict مالک — PII session-scoped.** مجوز کامل دیدن/پردازش نام و مبلغ در همین جلسه؛ خروجی‌ها فقط داخل پوشه. (استثنای صریح و موقتِ قاعدهٔ «PII وارد LLM نشود» — قاعدهٔ پیش‌فرض برای اتوماسیون‌ها پابرجاست.)
**اجرا — importer راستی‌آزمایی شد.** ۱۳/۱۳ تست + run واقعی ۱۶۰ تراکنش؛ REGISTRY: `csv_import: built+validated`. gap ثبت‌شده: GST روی برداشت نقدی، dedup فقط در DB-layer.
**اجرا — استخراج دفاتر.** شیت خلاصهٔ دستی با PS Exportها تطبیق داده شد (دقت ~۸$). sub-ledger پیش‌نویس: `drafts/associates-subledger-DRAFT-2026-07-12.md`.
**یافته — رسیدها واقعی نبودند.** ۴/۴ اسکرین‌شات چت؛ قرنطینهٔ برگشت‌پذیر `data/receipts/_not-receipts-quarantine-2026-07-12/`؛ ACC-V8 = blocked-on-data.
**اصلاح — نام‌فایل‌های فارسی.** انکدینگ `#Uxxxx` (حاصل zip/unzip) به یونیکد برگردانده شد.
**Flag — تناقض‌های مستندات.** MANIFEST (`pending_verdicts:0`، `gate:closed`، «۴ رسید») با VERDICT_QUEUE/RUNBOOK/واقعیت ناسازگار بود → فیلدهای stale در MANIFEST اصلاح و در گزارش flag شد. هیچ قاعدهٔ قفل‌شده‌ای تغییر نکرد.
