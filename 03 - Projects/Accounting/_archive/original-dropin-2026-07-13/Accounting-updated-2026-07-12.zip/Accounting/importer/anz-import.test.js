// anz-import.test.js — تست منطق خالص (بدون DB). اجرا: node anz-import.test.js
'use strict';
const A = require('./anz-import');

let pass = 0, fail = 0;
const eq = (name, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log(`${ok ? '✅' : '❌'} ${name}${ok ? '' : `  got=${JSON.stringify(got)} want=${JSON.stringify(want)}`}`);
  ok ? pass++ : fail++;
};
const ok = (name, cond) => { console.log(`${cond ? '✅' : '❌'} ${name}`); cond ? pass++ : fail++; };

const HEADER = 'Date,Merchant,Merchant Changed From,Amount,Currency,Transaction Type,Account,Closing Balance,Category,Parent Categories,Labels,Memo,Note,ID';
const mainCsv = [
  HEADER,
  '2024-10-01,Bunnings Warehouse,,-110,AUD,debit,ANZ Business Essentials,5000,,,,,,1001',
  '2024-10-02,Payment to Armin Mohebiafzal #832494,,-500,AUD,debit,ANZ Business Essentials,4500,,,,,,1002',
  '2024-10-03,"WOOLWORTHS 1163 KIAMA NS AUS, Card xx4178, Value date: 19/10/2024",,-22.60,AUD,debit,ANZ Plus,700,,,,,,1003',
  '2024-10-04,Visa Debit purchase card 5673 paypal *temu com,,-224.94,AUD,debit,ANZ Plus,475,,,,,,1004',
  '2024-10-05,DEBIT INTEREST,,-0.01,AUD,debit,ANZ Business Essentials,4499,,,,,,1005',
  '2024-10-06,Cash withdrawal business card,,-12000,AUD,debit,ANZ Business Essentials,-7501,,,,,,1006',
  '2024-10-07,Netflix.com Melbourne,,-7.99,AUD,debit,ANZ Plus,467,,,,,,1007',
].join('\n');

const rows = A.parseCsv(mainCsv);
const byId = (id) => A.processRow(rows.find((r) => r.ID === id));

// 1) parser: کاما داخل کوتیشن نباید فیلد را بشکند
ok('CSV parses quoted comma field', rows.length === 7 && rows[2].Merchant.includes('Card xx4178'));

// 2) GST درست: inclusive ÷ 11 ، خارجی = 0
eq('GST inclusive 110 -> {10,100}', A.computeGst(110, false), { gst: 10, net: 100 });
eq('GST-free overseas -> {0,x}', A.computeGst(224.94, true), { gst: 0, net: 224.94 });

// 3) Bunnings: business / Materials / GST 10 / no_abn flag
const bun = byId('1001');
ok('Bunnings -> Materials/business', bun.suggested_category === 'Materials' && bun.scope === 'business');
ok('Bunnings GST 10 net 100', bun.gst_amount === 10 && bun.amount_ex_gst === 100);
ok('Bunnings flags no_abn_check', bun.flags.includes('no_abn_check'));

// 4) Div7A: پرداخت به associate از حساب بیزنس
const arm = byId('1002');
ok('Payment to associate -> div7a flag', arm.flags.some((f) => f.startsWith('div7a_drawing:')));

// 5) Woolworths -> personal / Groceries
const woo = byId('1003');
ok('Woolworths -> Groceries/personal', woo.suggested_category === 'Groceries' && woo.scope === 'personal');

// 6) Temu -> gst_free
ok('Temu -> gst_free, gst 0', byId('1004').gst_free === true && byId('1004').gst_amount === 0);

// 7) Bank interest -> gst_free
ok('DEBIT INTEREST -> gst_free', byId('1005').gst_free === true && byId('1005').gst_amount === 0);

// 8) AUSTRAC threshold
ok('12000 -> austrac_10k', byId('1006').flags.includes('austrac_10k'));

// 9) reconciliation: یک مغایرت تزریق‌شده را می‌گیرد، سالم‌ها را false-positive نمی‌کند
const reconCsv = [
  HEADER,
  '2024-08-01,Opening,,-100,AUD,debit,ANZ Business Essentials,900,,,,,,2001',
  '2024-08-02,Payment B,,-50,AUD,debit,ANZ Business Essentials,850,,,,,,2002',
  '2024-08-03,Payment C,,-30,AUD,debit,ANZ Business Essentials,700,,,,,,2003',
].join('\n');
const mism = A.reconcile(A.parseCsv(reconCsv));
ok('reconcile catches exactly 1 mismatch (id 2003)', mism.length === 1 && mism[0].id === '2003');

// 10) buildDraft شکل کلی
const draft = A.buildDraft(rows);
ok('draft summary shape', draft.total_rows === 7 && Array.isArray(draft.flags) && draft.drafts.length === 7);

console.log(`\n${fail === 0 ? '🟢 ALL PASS' : '🔴 FAILURES'} — ${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
