---
type: knowledge
project: "[[03 - Projects/Accounting/PROJECT]]"
status: active
tags: [accounting]
created: 2026-07-04
updated: 2026-07-04
---

# OpenQuestions — Accounting

> مجهول‌ها. seed از [[03 - Projects/Accounting/PROJECT|PROJECT]] — 2026-07-04.

1. ردیف‌های `[To measure]` رجیستر انطباق: ACN · ABN · Director ID · تاریخ ASIC annual review · registered office · وضعیت GST · PAYG — فقط مالک.
2. حسابدار خارجی کیست؟ (انتخاب نشده) — پیش‌نیاز تأیید همهٔ قواعد `[Unverified]`.
3. نرم‌افزار حسابداری کدام؟ (Xero/MYOB/QuickBooks — انتخاب نشده). ⚡ شواهد جدید 2026-07-12: در دیتای واقعی هم MYOB و هم Xero هم‌زمان شارژ می‌شوند → ACC-V7 فوری‌تر شد.
4. آیا شرکت base rate entity است (نرخ ۲۵٪ vs ۳۰٪)؟ — تشخیص با حسابدار.
5. اگر نیرو گرفته شود: STP · payday super (از 2026-07-01) · NSW workers comp (icare) — وضعیت؟

### افزوده‌شده در جلسهٔ 2026-07-12 (از دیتای واقعی AUG–NOV 2024)

6. چرا حقوق Behzad (۱۹ تراکنش، ۹,۲۵۰$) به حساب «Armin Mohebiafzal» واریز شده؟ سند/توافقش کجاست؟
7. «رضا» کیست؟ (`کار کامل رضا`، ۴۰۰$) — در رجیستر associates نیست؛ worker چهارم؟ employee یا contractor؟
8. Rent (۱,۴۸۸ دوهفتگی): تجاری یا مسکونی؟ و ردیف‌های «recovered» یعنی چه (بازپس‌گیری/جبران)؟
9. حواله‌ها/پرداخت‌های بزرگ زیر برچسب sume asadi (Sydney Tehran Group · Kourosh Mahmoodi · Pb Holidays · Ehsan Davari · Ehsan Zamani · S Niazmand): ماهیت هرکدام؟ (شخصی/تجاری/تسویهٔ شریک)
10. آیا Sume Asadi شریک تجاری با تقسیم هزینهٔ ۵۰/۵۰ است؟ («۸×۳۵ xero باید نصف برمی‌داشتن»)
11. کدام حساب‌ها بیزنس‌اند؟ (ACC-V12) — ANZ Plus / COMPLETE FREEDOM / Smart Access / ANZ Save هرکدام چه نقشی؟
12. مرجع کد کجاست: `_code/` (تصمیم جلسه ۱۷) یا `app/` + `importer/` داخل همین پوشه (وضعیت zip فعلی)؟
13. ساختار قانونی دورهٔ AUG–NOV 2024 چه بود — sole trader یا Pty Ltd فعال? (تعیین‌کنندهٔ موضوعیت Div 7A برای همان دوره)
