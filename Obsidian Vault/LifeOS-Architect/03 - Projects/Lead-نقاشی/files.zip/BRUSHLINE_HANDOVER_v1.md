# BRUSHLINE — HANDOVER PACKAGE v1.0
**تاریخ:** 2026-07-02 | **هدف:** انتقال کامل context به یک پروژه‌ی دیگر — این فایل به‌تنهایی باید کافی باشد تا یک ایجنت/نشست تازه بدون هیچ فایل دیگری کار را ادامه دهد.
**زبان:** فارسی + termهای انگلیسی. **قاعده‌ی تقدم:** اگر چیزی با CONFIG مرکزی پروژه تعارض داشت، CONFIG برنده است.

> صداقت درباره‌ی scope: این سند از (۱) فایل‌های پروژه، (۲) این گفتگو و دو نشست قبلیِ paste‌شده، (۳) سند capabilities کد واقعی، و (۴) نتایج verify زنده‌ی 2026-07-02 ساخته شده. چت‌هایی که در context نبودند این‌جا نیستند.

---

## ۱. شناسنامه‌ی پروژه

| قلم | مقدار |
|---|---|
| نام | **Brushline** — placeholder؛ نام واقعی کسب‌وکار هنوز `null` |
| دامنه | نقاشی ساختمان (داخلی/بیرونی)، سیدنی، استرالیا |
| ماهیت | سیستم multi-agent بازاریابی/lead-gen با حاکمیت governance-first |
| معماری | **خواهرِ LANGAR** (reuse کتابخانه‌ها/interfaceها؛ DB و process جدا؛ هیچ JOIN با داده‌ی LANGAR) |
| استراتژی فعلی | **Capital Works / Strata به‌عنوان wedge اصلی** (نه فقط residential) — تغییر از Phase 5+ به اولویت ۱ |
| وضعیت | تئوری کامل (28+ فایل)، کد P1–P9 پیاده و تست‌شده، سیکل ۱ Autopilot بسته |
| محصول یک‌خطی | **Strata Paint Intelligence**: ارزیابی ۳۰ دقیقه‌ای + گزارش PDF «10-Year Exterior Painting Forecast» سازگار با فرم استاندارد CWF → ورود به چرخه‌ی تصمیم قبل از price war |

## ۲. تصمیم‌های قفل‌شده (bearing-load — بدون تأیید اپراتور تغییر نکن)

1. ماژول خواهر با reuse از LANGAR؛ نه داخل LANGAR، نه از صفر.
2. **draft → تأیید انسان → publish/send.** هیچ استثنا.
3. Owned-first: GBP + local SEO + suburb pages؛ hipages فقط پل موقت؛ **LSA در استرالیا وجود ندارد** — هر ادعای راه‌اندازی LSA در AU = کلاهبرداری.
4. Integrate نه duplicate: quoting/scheduling/invoicing → ServiceM8/Tradify (via Zapier/Make).
5. **سه invariant:** (الف) هیچ publish/spend/پیام بدون تأیید انسان؛ (ب) داده‌ی شخصی LANGAR هرگز وارد نشود + داده‌ی حساس مشتری وارد ابزار AI عمومی نشود، ذخیره ترجیحاً AU؛ (ج) هر auto-execution = kill switch + spend cap (per-action AUD 5 / روزانه AUD 20) + hash-chained audit log.
6. Eval با Wilson lower bound، نه pass rate خام (KB-08). متریک نهایی: **cost-per-booked-job (AUD)**.

## ۳. استراتژی Capital Works — پایه‌ی قانونی verify‌شده (2026-07-02)

- اصلاحات strata NSW از **۱ آوریل ۲۰۲۶** اجرایی است: هر پلن ۱۰ ساله‌ی capital works fund که **تهیه، بازنگری یا جایگزین** می‌شود باید با **فرم استاندارد** (Strata Hub planner یا فرم Word) باشد. پلن‌های موجودِ هنوز-due مستثنی‌اند → بازار یک‌جا باز نمی‌شود؛ **جریان چندساله از پلن‌هایی است که یکی‌یکی به موعد review می‌رسند** = دقیقاً همان چیزی که موتور تایمینگ AGM (#39) شکار می‌کند.
- فرم جدید هزینه‌های دسته‌بندی‌شده (structural, roofing, ... و painting داخل exterior maintenance) + inflation + sustainability را می‌خواهد → گزارش #40 باید با همین ساختار سازگار باشد.
- بازنگری پلن حداقل هر ۵ سال الزامی؛ best practice سالانه در AGM.

**سه pushback پذیرفته‌شده (در طراحی لحاظ شود):**
1. **زمین QS:** اکوسیستم برای پلن‌های due توصیه به quantity surveyor / building consultant می‌کند. گزارش تو باید صریحاً «**trade input for your CWF plan / QS**» برند شود، نه condition report مستقل؛ disclaimer استاندارد + برچسب «estimate» روی هر عدد + سؤال PI coverage از بیمه‌گر **قبل از اولین ارسال**. (در schema گزارش: mandatory_labels موجود است.)
2. **اقتصاد assessment رایگان = فرض، نه داده.** ریسک: مشاور مجانیِ رقبا شدن (گزارش گرفته می‌شود، tender به ارزان‌ترین نقاش می‌رود). mitigation: نسخه‌ی خلاصه رایگان، breakdown کامل per-m² فقط با quote. باید experiment با kill criteria باشد (E2).
3. این pivot تعریف conversion را عوض می‌کند: quote request → **assessment booked**. باید در KB-13/BLUEPRINT ثبت شود (هنوز ثبت نشده — TODO).

## ۴. وضعیت کد واقعی (از BRUSHLINE_CAPABILITIES.md — مبنا: 60_code/، P1–P9، ۱۱ فایل تست سبز)

**جریان‌های end-to-end کارکرده:** intake_enquiry (speed-to-lead، صف ۱۵ دقیقه)، پاسخ ریویو (sentiment با Haiku، منفی SLA ۲ ساعت)، suburb page (Serper research + Sonnet + gate دولایه: deterministic + semantic ACL ~$0.016/draft)، پست GBP (preview-only)، follow-up ۲/۵/۱۰ (تکی + batch با ۵۰٪ تخفیف + fallback)، consent recording، sync به ServiceM8/Tradify (consent-gated، whitelist ۸ فیلدی، dry-run بدون key، idempotent).
**رابط:** تلگرام تک‌اپراتور (`/queue` با Approve/Edit/Reject + REGATE روی ویرایش ماهوی، `/spend`, `/kill`, `/status`)، allow-list روی chat-id.
**Gate:** HARD_BLOCK برای بدون-consent / بدون-opt-out / بدون-ABN؛ SOFT_FLAG برای superlative/PII. سه invariant در کد enforce و تست‌شده. Audit chain با hash زنجیره‌ای + verify_chain.
**هزینه:** Haiku ~$0.004/draft، Sonnet فقط high-value، Opus خاموش؛ prompt caching؛ FX ثابت ۱.۴۵ در config (با verify امروز match).

**شکاف‌های go-live (صادقانه):** ارسال واقعی SMS/email بعد از تأیید (P11 — Worker G Sender)؛ پست زنده GBP (OAuth)؛ scheduler (P10)؛ Worker D تصویر = stub؛ **ارزیابی Capital Works = stub**؛ sync زنده verify‌نشده با مستندات فعلی CRMها؛ backup خودکار DB؛ deploy روی سرور.

## ۵. موتور Lead-Gen (KB-15 — ۵۰ روش، فشرده)

قاعده‌ی حاکم: Research/Signal = full-auto مجاز؛ هر Outreach/Publish/Spend = draft → constitution-gate → HITL. هیچ cold SMS/DM.
دسته‌ها: A) داده‌ی باز دولتی ۱–۱۰ (DA/CDC API، Strata Hub، eTendering، council capital works، Heritage، STRA) · B) اکوسیستم Google ۱۱–۱۸ (suburb pages، GBP cadence، Places density، review-mining رقبا، Search Console، Trends، Ads harvesting، **Street View time-series = هسته‌ی فنی SPI**) · C) هوش تصویری ۱۹–۲۳ (Nearmap، drive-by app، مدل فرسایش ساحلی، BOM trigger، UV per-facade) · D) real estate ۲۴–۳۰ · E) مانیتور اجتماعی read-only ۳۱–۳۶ · F) موتور B2B/Capital Works ۳۷–۴۳ (master DB مدیران، کمپین assessment، AGM timing، ژنراتور گزارش، کیت PM، referral loop، Dulux/Taubmans) · G) فلایویل owned ۴۴–۵۰ (review request، speed-to-lead، missed-call textback، chatbot، follow-up، repaint reminder، scoring fusion #50).
موج‌ها: W1=4,5,6,37,39 · W2=45,46,44,47 · W3=1,2,18,20,40 · W4=11,12,13,38,50. فعال‌سازی موج بعد فقط بعد از pass متریک موج قبل (Wilson).

## ۶. حلقه‌ی Autopilot (خلاصه‌ی عملیاتی)

هر اجرا = یک سیکل: PHASE 0 LOAD&FRAME → 1 VERIFY (زنده، I4) → 2 BUILD TARGET UNIVERSE (هر رکورد با source_id) → 3 SCORE → 4 EXPERIMENT (فرمت اجباری: hypothesis/smallest_test/metric+threshold/cost_cap/kill_criteria؛ حداکثر ۳ باز) → 5 DRAFT&GATE → 6 MEASURE&LEARN + خروجی فایل کامل STATE (نه diff).
Invariantهای پرامپت: I1 هیچ send بدون تأیید · I2 ایمیل B2B فقط آدرس کاری آشکارا منتشرشده + مرتبط با نقش + sender ID/ABN + unsubscribe؛ شک داری → نفرست · I3 هیچ ادعای اثبات‌نشده (ACL) · I4 هر factual volatile را web-search کن · I5 سقف cycle_budget_aud=15 · I6 داده‌ی شخصی افراد فقط از enquiry مستقیم.
یادداشت اپراتور: سیکل ۱–۲ فقط Phase 0–3؛ batch اول ایمیل = ۱۰ تایی؛ آدرس با notice «no unsolicited emails» ممنوع.

## ۷. نتایج VERIFY زنده — سیکل ۱ (2026-07-02) ✅

| مورد | نتیجه |
|---|---|
| #4 Strata search | عمومی، رایگان، بدون login. برمی‌گرداند: agent name+licence، SP، آدرس، **registration date**، lots، last AGM، annual reporting. contact جزئیات agent عمومی نیست → ایمیل از سایت agency/دایرکتوری. بونوس: «Strata manager finder» (login رایگان) = دایرکتوری agentها per-area |
| #5 Spatial dataset | باز، **آپدیت هفتگی**، SP polygons + scheme details + geocoded address؛ data.nsw.gov.au → portal.spatial.nsw.gov.au؛ کیفیت «indicative» |
| #6 LRS | **demote به fallback** — سن ساختمان از #4 مجانی درمی‌آید |
| #37 ABN Lookup | GUID رایگان با ثبت‌نام؛ JSON محدود؛ سقف ~۲۰۰ نتیجه per call؛ بدون داده‌ی director (ASIC لازم) |
| #39 AGM engine | فیلدها تأیید؛ گزارش سالانه ظرف ۳ ماه بعد از AGM الزامی → cross-check. قلاب طلایی: هر پلنی که در آن AGM بازنگری شود باید به فرم استاندارد برود |
| Google Places pricing | SKU-based (بازسازی Mar-2025)؛ کردیت $200 حذف؛ free cap per-SKU (~10k/5k/1k events)؛ Place Details Pro ~USD 17/1k؛ **سقف ۶۰ نتیجه per search** → tile کردن suburb برای #13 |
| Spam Act جریمه | **per-day، penalty-unit**: >۵۰ CEM بدون consent در یک روز → تا ۱٬۰۰۰ unit (~AUD 313–330k)؛ رکورد ACMA: Sportsbet 2.5M، تا 3.55M. unsubscribe ≤۵ روز کاری، فعال ≥۳۰ روز |
| ⏰ SMS Sender ID Register | **از 2026-07-01 اجباری** — قبل از هر کانال SMS (حتی #46) ثبت کن؛ فعلاً email-only |
| FX | 1 USD ≈ **1.45 AUD** (AUD/USD ~0.689) — با config کد match |

Phase 2 (build targets) عمداً اجرا نشد: enumerate کردن SPها دسترسی portal/API می‌خواهد، نه web search — جعل داده ممنوع (I4).

## ۸. Compliance snapshot (برای هر نشست جدید)

Spam Act 2003: consent صریح یا inferred معتبر (رابطه‌ی تجاری مرتبط)؛ sender name+ABN در هر پیام؛ unsubscribe functional. · ACL s29: هیچ superlative/warranty بی‌مدرک. · Privacy: APP 7، **APP 1.7 ADM disclosure از دسامبر ۲۰۲۶** (به AI lead handling مستقیماً می‌خورد — قبل از go-live disclosure آماده کن)؛ statutory tort فعال از ژوئن ۲۰۲۵؛ data residency ترجیحاً AU. · DNC Register برای تماس صوتی.

## ۹. تصمیم‌ها و ورودی‌های باز (بلاک‌کننده‌های واقعی)

| # | مورد | وضعیت |
|---|---|---|
| 1 | `avg_margin_per_job_aud`, `enquiry_to_quote_rate`, `quote_to_job_rate` | **null — تنها شرط باز DoR**؛ بدونش cost-per-booked-job و کالیبراسیون scoring معنا ندارد |
| 2 | `business_name` + `abn` + `sender_id` | null — بلاک‌کننده‌ی هر outreach/عضویت (Wave 4, E1, E3) |
| 3 | partner-first (E1: شرکت‌های QS/CWF مثل Solutions in Engineering, QIA Group, SFA) یا inbound-first (E3: Master Painters + Dulux Accredited + دایرکتوری‌ها)؟ | معلق — **پیشنهاد ثبت‌شده: partner-first**، چون نویسنده‌های پلن CWF زودتر از هر feed به تصمیم repaint می‌رسند |
| 4 | افزودن منابع پیشنهادی ۵۱–۷۵ (لایه‌های institutional panels / referral partners / accreditation / content) به source_registry | معلق — طراحی کامل در نشست قبلی موجود؛ مهم‌ترین: **#59 QS/CWF providers (prio 10, wave 1)**، #52 Building Commission rectification، #65 scaffolding referral |
| 5 | ثبت pivot در KB-13/BLUEPRINT (سگمنت اولویت + conversion=assessment booked) | TODO |
| 6 | PI insurance برای گزارش‌های forecast | TODO قبل از اولین ارسال |
| 7 | `final_service_suburbs` | فرض فعلی: ۸ seed (اولویت ساحلی: Bondi/Manly/Cronulla، coastal_km=0) |

## ۱۰. اکوسیستم فایل‌ها (نقش هر کدام)

`BLUEPRINT_v2` معماری ۶ Worker + gate + صف · `ROADMAP_v2` فازها/DoD/milestones · `KB-10` prompt library · `KB-11` مهندسی (Anthropic patterns، eval-driven، anti-patterns) · `KB-12` compliance AU · `KB-13` تحقیق عمیق بازار · `KB-15` ۵۰ روش lead-gen · `PROMPT_LEADGEN_AUTOPILOT_v1` پرامپت Orchestrator · `DATA_leadgen_seed` منبع حقیقت STATE (نسخه‌ی verify‌شده در پیوست همین فایل) · `BRUSHLINE_CAPABILITIES` وضعیت کد · `CLAUDE_PROJECT_SETUP_v2` راه‌اندازی Project · fusion checklist: ۷ قانون حاکمیتی (metabolism/budget، HITL، شفافیت/tracing، least-privilege، no-SPOF، تفکیک نقش، testability).

## ۱۱. پیوست — STATE کامل v1.1 (سیکل ۱ بسته، verify‌شده)

این JSON جایگزین `DATA_leadgen_seed_v1.json` است؛ در پروژه‌ی جدید همین را کنار پرامپت Autopilot بگذار:

```json
{
  "meta": {
    "name": "Brushline Lead-Gen Autopilot Seed Data",
    "version": "1.0",
    "date": "2026-07-02",
    "domain": "building painting, Sydney AU + Capital Works / strata segment",
    "currency": "AUD",
    "companion_files": [
      "KB-15_leadgen_engine_50_methods_v1.md",
      "PROMPT_LEADGEN_AUTOPILOT_v1.md"
    ],
    "single_source_of_truth_note": "If any parameter conflicts with project CONFIG, CONFIG wins."
  },
  "state": {
    "current_cycle": 1,
    "current_wave": 1,
    "open_experiments": [],
    "budget_spent_aud": 0,
    "cycle_history": [
      {
        "cycle": 1,
        "date": "2026-07-02",
        "wave": 1,
        "phases_executed": [
          "0-frame",
          "1-verify (LIVE web search)",
          "6-measure"
        ],
        "phases_deferred": [
          "2-build (needs portal/API access)",
          "3-score (runs on first data load)",
          "4-experiment",
          "5-draft"
        ],
        "metrics": {
          "sources_verified": 5,
          "config_params_verified": 3,
          "targets_added": 0,
          "drafts_produced": 0,
          "sent": 0,
          "cost_aud": 0
        },
        "learnings": [
          "Registration date is returned by public Strata search (#4) itself -> #6 (LRS) demoted to fallback.",
          "SMS Sender ID Register mandatory from 1 July 2026 — register before ANY SMS channel; email-only until then.",
          "30% of scoring weight (paint_condition 0.20 + recent_da 0.10) structurally inactive until Wave 3 -> re-rank at Wave 3."
        ]
      }
    ]
  },
  "config": {
    "cycle_budget_aud": 15,
    "monthly_tool_budget_aud": 40,
    "max_concurrent_experiments": 3,
    "b2b_email_batch_size_initial": 10,
    "speed_to_lead_target_minutes": 60,
    "followup_days": [
      2,
      5,
      10
    ],
    "review_request_delay_hours": 24,
    "repaint_cycle_years": {
      "exterior_coastal": 7,
      "exterior_inland": 10,
      "interior": 8
    }
  },
  "compliance_rules": {
    "spam_act": {
      "no_cold_sms_dm": true,
      "b2b_email_conditions": [
        "address conspicuously published as business contact",
        "no 'no unsolicited email' notice attached",
        "offer directly relevant to recipient's role",
        "sender name + ABN in every message",
        "functional unsubscribe honoured within 5 business days"
      ],
      "suppression_list_required": true,
      "penalty_range_aud": "per-day penalty-unit basis; >50 non-consented CEMs/day -> up to 1,000 units (~AUD 330k); ACMA record AUD 2.5M-3.55M (verified 2026-07-02)",
      "sms_sender_id_register": "MANDATORY from 2026-07-01 (ACMA): register sender ID with telco before ANY branded SMS (incl. #46 missed-call textback)."
    },
    "acl": {
      "no_unsubstantiated_claims": true,
      "banned_patterns": [
        "best in Sydney",
        "guaranteed",
        "warranty (without documented terms)",
        "certified (without evidence)"
      ]
    },
    "privacy": {
      "no_personal_data_of_individuals_without_enquiry": true,
      "no_sensitive_customer_data_into_public_ai_tools": true,
      "data_residency": "AU preferred",
      "app_1_7_adm_disclosure_deadline": "2026-12"
    },
    "gates": {
      "all_outreach": "draft -> constitution_gate -> human_approve",
      "all_spend": "human_approve + spend_cap",
      "all_publish": "human_approve"
    }
  },
  "source_registry": [
    {
      "id": 1,
      "name": "NSW Planning Portal Online DA Data API",
      "cat": "gov_data",
      "signal": "approved renovation/alteration DAs -> repaint in 3-9 months",
      "autonomy": "AUTO",
      "gate": "none (research)",
      "cost_aud_month": 0,
      "access": "free API key via eplanning data broker email, CC-BY",
      "priority": 9,
      "wave": 3,
      "verified_date": "2026-07-02",
      "access_status": "confirmed available",
      "notes": "feed of all DAs lodged since Jan 2019, all councils mandated since 2021-07"
    },
    {
      "id": 2,
      "name": "Online CDC Data API",
      "cat": "gov_data",
      "signal": "complying development approvals (faster than DA)",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "access": "same key family as DA API",
      "priority": 8,
      "wave": 3,
      "verified_date": "2026-07-02",
      "access_status": "confirmed available"
    },
    {
      "id": 3,
      "name": "PCC / Occupation Certificate feeds",
      "cat": "gov_data",
      "signal": "newly completed buildings -> handover paint now + repaint clock start",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 3
    },
    {
      "id": 4,
      "name": "Strata search (Strata Hub public)",
      "cat": "gov_data",
      "signal": "per-scheme: managing agent name+licence, last AGM date, annual reporting date, lots",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "access": "free public web search",
      "priority": 10,
      "wave": 1,
      "verified_date": "2026-07-02",
      "access_status": "VERIFIED live: free public web search, no login",
      "notes": "Returns: managing agent name+licence, SP number, address, REGISTRATION DATE, lot info, last AGM date, annual reporting completion. Agent contact details NOT public (strata-roll only) -> emails via agency sites/directories per #37. Bonus: 'Strata manager finder' directory in Strata Hub (free login) lists agents by service area. Annual report due within 3 months of each AGM."
    },
    {
      "id": 5,
      "name": "NSW Strata Hub spatial dataset",
      "cat": "gov_data",
      "signal": "geocoded SP polygons of all NSW strata schemes, weekly updates, open data",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 9,
      "wave": 1,
      "verified_date": "2026-07-02",
      "access_status": "VERIFIED live: open data, updated weekly",
      "notes": "DCS Spatial Services 'NSW Strata Hub' product: SP polygons + scheme details + geocoded addresses; data.nsw.gov.au dataset id 1-cb153150..., served via portal.spatial.nsw.gov.au web service. Caveats: indicative, registered titles only. Pipeline: polygon-in-suburb -> sp_number -> feed #4."
    },
    {
      "id": 6,
      "name": "NSW LRS strata plan registration date",
      "cat": "gov_data",
      "signal": "building age from SP number -> repaint-due model",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 8,
      "wave": 1,
      "verified_date": "2026-07-02",
      "access_status": "DEMOTED to fallback",
      "notes": "Not needed: registration date returned by #4 directly. Fallback only; LRS/HLRV lookups may be paid."
    },
    {
      "id": 7,
      "name": "NSW eTendering + council tender portals",
      "cat": "gov_data",
      "signal": "commercial/government repaint tenders",
      "autonomy": "AUTO signal / HITL bid",
      "gate": "human decides bids",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 8,
      "name": "Council published capital works programs",
      "cat": "gov_data",
      "signal": "multi-year building maintenance pipelines",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 9,
      "name": "Heritage NSW database",
      "cat": "gov_data",
      "signal": "heritage-listed buildings = high-margin specialist niche",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 4,
      "wave": 4
    },
    {
      "id": 10,
      "name": "STRA Register (Planning Portal)",
      "cat": "gov_data",
      "signal": "short-term rental properties -> refresh demand via agents",
      "autonomy": "AUTO signal",
      "gate": "outreach via agent only",
      "cost_aud_month": 0,
      "priority": 4,
      "wave": 4
    },
    {
      "id": 11,
      "name": "Programmatic suburb pages",
      "cat": "google",
      "signal": "owned SEO engine, locally-unique content",
      "autonomy": "DRAFT",
      "gate": "constitution + human publish",
      "cost_aud_month": 0,
      "priority": 9,
      "wave": 4
    },
    {
      "id": 12,
      "name": "GBP cadence (posts/photos/QA)",
      "cat": "google",
      "signal": "map pack ranking",
      "autonomy": "DRAFT",
      "gate": "human publish",
      "cost_aud_month": 0,
      "priority": 9,
      "wave": 4
    },
    {
      "id": 13,
      "name": "Places API competitor density scan",
      "cat": "google",
      "signal": "underserved suburbs = expansion targets",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 5,
      "access": "Google Places API, verify per-request pricing (CONFIG open param)",
      "priority": 8,
      "wave": 4
    },
    {
      "id": 14,
      "name": "Competitor review mining",
      "cat": "google",
      "signal": "competitor weaknesses (slow response, no-show quotes) -> positioning",
      "autonomy": "AUTO",
      "gate": "never name competitors in copy (ACL)",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 4
    },
    {
      "id": 15,
      "name": "Search Console query harvesting",
      "cat": "google",
      "signal": "impression queries without pages -> new content targets",
      "autonomy": "AUTO analysis / DRAFT content",
      "gate": "human publish",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 4
    },
    {
      "id": 16,
      "name": "Google Trends regional",
      "cat": "google",
      "signal": "seasonal demand curves per service type",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 17,
      "name": "Google Ads keyword harvesting",
      "cat": "google",
      "signal": "winning search terms, negative pruning, bid suggestions",
      "autonomy": "HITL",
      "gate": "spend cap + human approve",
      "cost_aud_month": "campaign budget (separate)",
      "priority": 6,
      "wave": 4
    },
    {
      "id": 18,
      "name": "Street View time-series facade scoring",
      "cat": "vision_geo",
      "signal": "paint condition score from multi-year imagery, no site visit",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 10,
      "priority": 9,
      "wave": 3,
      "notes": "core of Strata Paint Intelligence"
    },
    {
      "id": 19,
      "name": "Aerial imagery (Nearmap/Metromap)",
      "cat": "vision_geo",
      "signal": "high-res facade/roof condition",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": "verify pricing - likely too expensive early",
      "priority": 3,
      "wave": 4
    },
    {
      "id": 20,
      "name": "Drive-by capture app pipeline",
      "cat": "vision_geo",
      "signal": "photo+address -> geocode -> Strata Hub crossref -> agent found -> draft assessment",
      "autonomy": "AUTO to draft",
      "gate": "human approves any contact",
      "cost_aud_month": 0,
      "priority": 10,
      "wave": 3
    },
    {
      "id": 21,
      "name": "Coastal salt-exposure model",
      "cat": "vision_geo",
      "signal": "distance-to-coast x facade orientation x age -> degradation score",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 3
    },
    {
      "id": 22,
      "name": "Weather triggers (BOM API)",
      "cat": "vision_geo",
      "signal": "post-storm/hail inspection campaigns (owned + consented lists only)",
      "autonomy": "DRAFT",
      "gate": "constitution + human send",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 23,
      "name": "UV/facade orientation model",
      "cat": "vision_geo",
      "signal": "north/west facades degrade faster -> report differentiation",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 4,
      "wave": 4
    },
    {
      "id": 24,
      "name": "Sale listing monitor (Domain/REA)",
      "cat": "real_estate",
      "signal": "new listings without 'freshly painted' -> pre-sale paint offer to AGENT (B2B)",
      "autonomy": "AUTO signal / DRAFT agent message",
      "gate": "B2B email conditions + human",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 4
    },
    {
      "id": 25,
      "name": "Auction results",
      "cat": "real_estate",
      "signal": "post-settlement reno wave; channel = agent co-marketing, never direct to buyer",
      "autonomy": "AUTO signal",
      "gate": "no direct-to-individual contact (privacy)",
      "cost_aud_month": 0,
      "priority": 4,
      "wave": 4
    },
    {
      "id": 26,
      "name": "Rental listing churn",
      "cat": "real_estate",
      "signal": "high-churn property managers = repeat end-of-lease paint clients",
      "autonomy": "AUTO",
      "gate": "B2B rules for outreach",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 4
    },
    {
      "id": 27,
      "name": "Listing keyword detection",
      "cat": "real_estate",
      "signal": "'renovator's delight' / 'original condition' -> signal to listing agent",
      "autonomy": "AUTO",
      "gate": "B2B rules",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 28,
      "name": "Airbnb/STRA host monitoring",
      "cat": "real_estate",
      "signal": "multi-property hosts with 'tired/dated' reviews",
      "autonomy": "AUTO signal",
      "gate": "compliant channel only",
      "cost_aud_month": 0,
      "priority": 3,
      "wave": 4
    },
    {
      "id": 29,
      "name": "Commercial make-good signals",
      "cat": "real_estate",
      "signal": "lease expiries -> mandatory make-good painting via commercial agents",
      "autonomy": "AUTO signal",
      "gate": "B2B rules",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 30,
      "name": "Development completion tracking",
      "cat": "real_estate",
      "signal": "PCC/OC -> active local builders -> subcontract pipeline",
      "autonomy": "AUTO",
      "gate": "B2B rules",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 3
    },
    {
      "id": 31,
      "name": "Facebook local groups monitor",
      "cat": "social_readonly",
      "signal": "'recommend a painter' posts -> alert, HUMAN replies (no bots - ban risk)",
      "autonomy": "AUTO alert",
      "gate": "human replies personally",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 4
    },
    {
      "id": 32,
      "name": "Nextdoor monitor",
      "cat": "social_readonly",
      "signal": "neighbourhood recommendation requests",
      "autonomy": "AUTO alert",
      "gate": "human replies",
      "cost_aud_month": 0,
      "priority": 4,
      "wave": 4
    },
    {
      "id": 33,
      "name": "Reddit monitor",
      "cat": "social_readonly",
      "signal": "r/sydney + suburb subs painter requests; disclosed human replies",
      "autonomy": "AUTO alert",
      "gate": "human replies, disclose business",
      "cost_aud_month": 0,
      "priority": 3,
      "wave": 4
    },
    {
      "id": 34,
      "name": "hipages/Airtasker demand intel",
      "cat": "social_readonly",
      "signal": "request volume + pricing per suburb (READ ONLY, do not buy leads)",
      "autonomy": "AUTO",
      "gate": "none",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 2
    },
    {
      "id": 35,
      "name": "LinkedIn new appointments",
      "cat": "social_readonly",
      "signal": "newly appointed strata/property managers = golden relationship window",
      "autonomy": "AUTO signal / DRAFT message",
      "gate": "human sends",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 4
    },
    {
      "id": 36,
      "name": "SCA NSW directory + events",
      "cat": "social_readonly",
      "signal": "strata industry body members, events, sponsorship channel",
      "autonomy": "AUTO research / HITL sponsorship",
      "gate": "human decides spend",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 4
    },
    {
      "id": 37,
      "name": "Strata manager master database",
      "cat": "b2b_strata",
      "signal": "fusion: Strata Hub agents x directories x ABN Lookup API x websites -> full agency records",
      "autonomy": "AUTO",
      "gate": "business data only",
      "cost_aud_month": 0,
      "priority": 10,
      "wave": 1,
      "verified_date": "2026-07-02",
      "access_status": "VERIFIED: ABN Lookup web services free (GUID by registration)",
      "notes": "Free GUID via abr.business.gov.au; JSON support limited; name/postcode searches capped ~200 results; NO director data (use ASIC). Fusion inputs: #4 agent+licence, Strata manager finder, NSW Fair Trading licence check, agency websites."
    },
    {
      "id": 38,
      "name": "Capital Works Assessment campaign",
      "cat": "b2b_strata",
      "signal": "free assessment offer to strata managers, small personalised batches",
      "autonomy": "DRAFT + HITL",
      "gate": "full Spam Act B2B conditions + constitution + human per batch",
      "cost_aud_month": 0,
      "priority": 10,
      "wave": 4
    },
    {
      "id": 39,
      "name": "AGM-cycle timing engine",
      "cat": "b2b_strata",
      "signal": "last AGM date -> contact window 2-3 months before next AGM (capital works plan review)",
      "autonomy": "AUTO scheduling",
      "gate": "outreach gated as #38",
      "cost_aud_month": 0,
      "priority": 10,
      "wave": 1,
      "verified_date": "2026-07-02",
      "access_status": "VERIFIED: last_agm_date + annual_reporting fields public in #4",
      "notes": "next_agm_estimate = last_agm+12mo; contact_window = next_agm - 2-3mo. Post-Apr-2026 hook: any plan reviewed/replaced at that AGM must move to standard CWF form -> strongest opener."
    },
    {
      "id": 40,
      "name": "10-Year Exterior Painting Forecast generator",
      "cat": "b2b_strata",
      "signal": "photos + age + degradation model -> 2-3 page PDF compatible with capital works fund plan form",
      "autonomy": "AUTO to draft / HITL send",
      "gate": "no unsubstantiated claims, estimates labelled as estimates",
      "cost_aud_month": 2,
      "priority": 10,
      "wave": 3
    },
    {
      "id": 41,
      "name": "Property manager co-marketing kits",
      "cat": "b2b_strata",
      "signal": "PM forwards your material to owners (they send, not you -> consent solved)",
      "autonomy": "DRAFT",
      "gate": "human approves kit",
      "cost_aud_month": 0,
      "priority": 7,
      "wave": 4
    },
    {
      "id": 42,
      "name": "Builder/agent referral loop",
      "cat": "b2b_strata",
      "signal": "post-job referral requests + lead source tracking in CRM",
      "autonomy": "DRAFT",
      "gate": "human approves templates",
      "cost_aud_month": 0,
      "priority": 6,
      "wave": 4
    },
    {
      "id": 43,
      "name": "Paint supplier trade networks",
      "cat": "b2b_strata",
      "signal": "Dulux/Taubmans trade programs refer painters",
      "autonomy": "HITL one-off",
      "gate": "human",
      "cost_aud_month": 0,
      "priority": 5,
      "wave": 4
    },
    {
      "id": 44,
      "name": "Review request automation",
      "cat": "owned_flywheel",
      "signal": "job complete (CRM webhook) -> +24h review request; negative feedback routed private",
      "autonomy": "AUTO after template approval",
      "gate": "existing business relationship = valid consent",
      "cost_aud_month": 0,
      "priority": 9,
      "wave": 2
    },
    {
      "id": 45,
      "name": "Speed-to-lead",
      "cat": "owned_flywheel",
      "signal": "instant ack + drafted full reply in human queue; meaningful reply < 60 min",
      "autonomy": "AUTO ack / DRAFT reply",
      "gate": "first customer message human-approved",
      "cost_aud_month": 0,
      "priority": 10,
      "wave": 2
    },
    {
      "id": 46,
      "name": "Missed-call textback",
      "cat": "owned_flywheel",
      "signal": "missed call -> instant SMS 'got your message' (reply to customer's own contact = permitted)",
      "autonomy": "AUTO",
      "gate": "template pre-approved",
      "cost_aud_month": 5,
      "priority": 9,
      "wave": 2
    },
    {
      "id": 47,
      "name": "Website chatbot 24/7",
      "cat": "owned_flywheel",
      "signal": "capture scope/suburb/photos -> CRM sync -> speed-to-lead queue",
      "autonomy": "AUTO capture",
      "gate": "ADM disclosure (APP 1.7 from Dec 2026)",
      "cost_aud_month": 35,
      "priority": 8,
      "wave": 2
    },
    {
      "id": 48,
      "name": "Follow-up sequences 2/5/10",
      "cat": "owned_flywheel",
      "signal": "consented enquiries only; all drafted, sent on approval or pre-approved templates",
      "autonomy": "DRAFT",
      "gate": "consent + opt-out on every message",
      "cost_aud_month": 0,
      "priority": 9,
      "wave": 2
    },
    {
      "id": 49,
      "name": "Past-customer repaint reminders",
      "cat": "owned_flywheel",
      "signal": "own CRM: jobs 7-10 years old -> free inspection campaign (existing relationship)",
      "autonomy": "DRAFT",
      "gate": "opt-out honoured",
      "cost_aud_month": 0,
      "priority": 8,
      "wave": 4
    },
    {
      "id": 50,
      "name": "Multi-signal scoring + weekly autopilot report",
      "cat": "owned_flywheel",
      "signal": "fusion layer: all signals -> score per building/manager/suburb -> prioritised weekly queue with reasons",
      "autonomy": "AUTO analysis / human decides",
      "gate": "none (analysis)",
      "cost_aud_month": 5,
      "priority": 10,
      "wave": 4
    }
  ],
  "suburb_seeds": [
    {
      "suburb": "North Sydney",
      "coastal_km": 3,
      "strata_density": "very_high",
      "segment_bias": "strata/commercial"
    },
    {
      "suburb": "Chatswood",
      "coastal_km": 8,
      "strata_density": "very_high",
      "segment_bias": "strata/residential"
    },
    {
      "suburb": "Bondi",
      "coastal_km": 0,
      "strata_density": "very_high",
      "segment_bias": "strata, short repaint cycle (salt)"
    },
    {
      "suburb": "Parramatta",
      "coastal_km": 20,
      "strata_density": "high",
      "segment_bias": "strata/commercial/builder"
    },
    {
      "suburb": "Ryde",
      "coastal_km": 12,
      "strata_density": "high",
      "segment_bias": "strata/residential"
    },
    {
      "suburb": "Inner West (Marrickville/Ashfield/Leichhardt)",
      "coastal_km": 6,
      "strata_density": "high",
      "segment_bias": "residential/strata, older stock"
    },
    {
      "suburb": "Manly",
      "coastal_km": 0,
      "strata_density": "high",
      "segment_bias": "strata, salt exposure premium"
    },
    {
      "suburb": "Cronulla",
      "coastal_km": 0,
      "strata_density": "medium",
      "segment_bias": "strata, salt exposure"
    }
  ],
  "schemas": {
    "strata_target": {
      "sp_number": "string",
      "address": "string",
      "suburb": "string",
      "managing_agent": "string",
      "agent_licence": "string",
      "agent_email_published": "string|null",
      "last_agm_date": "date",
      "next_agm_estimate": "date",
      "lots": "int",
      "registration_year": "int",
      "building_age_years": "int",
      "coastal_km": "float",
      "paint_condition_score": "0-10|null",
      "photos": [
        "path"
      ],
      "source_id": "int",
      "score": "float",
      "status": "new|assessed|drafted|approved|contacted|replied|quoted|won|lost|suppressed"
    },
    "building_assessment_report": {
      "title": "10-Year Exterior Painting Forecast",
      "sections": [
        "current_condition (photos + score)",
        "risk_of_delay (substrate damage cost curve)",
        "recommended_window (year)",
        "cost_estimate_today (range, labelled estimate)",
        "assumptions_and_method"
      ],
      "format": "PDF 2-3 pages, compatible with NSW capital works fund plan form",
      "mandatory_labels": [
        "estimates clearly marked",
        "no warranty claims without documented terms",
        "prepared-by + ABN"
      ]
    },
    "experiment_log_entry": {
      "id": "string",
      "date": "date",
      "hypothesis": "string",
      "smallest_test": "string",
      "metric": "string",
      "success_threshold": "number",
      "cost_cap_aud": "number",
      "kill_criteria": "string",
      "result": "pending|pass|fail|killed",
      "wilson_lower_bound": "float|null",
      "learnings": "string",
      "scoring_weight_changes": "object|null"
    }
  },
  "scoring_model": {
    "note": "initial guesses - recalibrate every cycle against real quote/job outcomes, log every weight change",
    "weights": {
      "building_age_in_repaint_window": 0.25,
      "coastal_salt_exposure": 0.15,
      "paint_condition_score": 0.2,
      "agm_window_open_next_90d": 0.15,
      "agent_portfolio_size": 0.1,
      "recent_da_or_reno_signal": 0.1,
      "suburb_priority": 0.05
    },
    "hard_filters": [
      "status != suppressed",
      "no 'no unsolicited email' notice on published address",
      "within service suburbs"
    ]
  },
  "kpi_targets": {
    "cycle": {
      "new_verified_targets": 30,
      "drafts_to_queue": "<=20",
      "cost_aud": "<=15"
    },
    "90_day": {
      "assessments_delivered": 20,
      "strata_manager_relationships": 5,
      "quotes_from_capital_works": 8,
      "cost_per_booked_job_aud": "measure baseline first, then improve"
    },
    "eval_method": "Wilson lower bound for A/B comparisons (KB-08), never raw pass rate"
  },
  "open_config_params": {
    "business_name": null,
    "abn": null,
    "sender_id": null,
    "final_service_suburbs": null,
    "avg_margin_per_job_aud": null,
    "enquiry_to_quote_rate": null,
    "quote_to_job_rate": null,
    "google_places_per_request_pricing": "VERIFIED 2026-07-02: SKU-based since Mar-2025 restructure; universal $200/mo credit ELIMINATED, per-SKU free caps (~10k Essentials / 5k Pro / 1k Enterprise events/mo). Place Details Pro ~USD 17/1k (10k-100k tier). Hard cap 60 results/search (20x3 pages) -> tile suburbs for #13.",
    "spam_act_penalty_figures": "VERIFIED 2026-07-02: per-day penalty-unit basis (Sch 3). >50 non-consented CEMs in one day -> up to 1,000 penalty units (~AUD 313-330k). ACMA record infringements: Sportsbet AUD 2.5M; AUD 3.55M cited. Unsubscribe actioned <=5 business days, functional >=30 days.",
    "fx_rate_usd_aud": "VERIFIED 2026-07-02: AUD/USD ~0.689 -> 1 USD ~ 1.45 AUD (matches config in code); re-check monthly"
  },
  "experiment_log": []
}
```

## ۱۲. آپدیت — تارگت‌های واقعی E1 (verify‌شده 2026-07-03)

پیشنهاد استراتژی «Capital Works entry» که در این نشست رسید، عملاً تأیید مسیر partner-first بود (نه استراتژی جدید) — ولی ۵ اسم واقعی شرکت strata management آورد که با web search verify شدند:

| شرکت | منطقه | آماده‌ی outreach؟ |
|---|---|---|
| **Strata Republic** | سیدنی + Byron Bay | ✅ READY — ایمیل مستقیم + ABN + شماره‌ی لایسنس روی سایت منتشر شده (بهترین inferred-consent case) |
| Jamesons Strata Managers | CBD & Inner West | فقط فرم تماس — قبل از ارسال ایمیل مستقیم پیدا شود |
| Premium Strata | Mascot / سیدنی متروپولیتن | فقط تلفن — قبل از ارسال ایمیل مستقیم پیدا شود |
| Strata Sense | سیدنی + نیوکاسل | فقط فرم تماس |
| Strata United | سیدنی | فقط فرم تماس |

**ریسک تکراری هنوز باز:** این‌ها آژانس‌های جاافتاده با شبکه‌ی پیمانکار خودشان‌اند — گزارش رایگان می‌تواند به پیمانکار *آن‌ها* ارجاع شود، نه Brushline. E2 (۱۰ ایمیل، kill criteria مشخص) پیش‌نیاز است، نه گزینه.

**درباره‌ی سند "MASTER KNOWLEDGE EXTRACTION PROMPT":** این پرامپت (از یک چت‌لاگ دیگر، منسوب به «ari») بدون تغییر اجرا نشد — دو دلیل: (۱) به «هر پروژه/چت» کاربر دسترسی واقعی وجود ندارد، فقط به همین پروژه‌ی Brushline؛ ادعای استخراج مباحث quantum/consciousness/mining از جایی که وجود ندارد = جعل. (۲) دستور «ادامه‌ی خودکار بی‌پایان در چند پاسخ» قابل تعهد نیست. اگر کاربر ساختار آن (فولدربندی، PromptLibrary.md، DecisionLog.md، ...) را فقط **روی محتوای واقعی همین پروژه** بخواهد، در دسترس است — منتظر تأیید.

فایل کامل STATE با این targetها: `DATA_leadgen_seed_v1.2.json` (پیوست جدا، جایگزین نسخه‌ی v1.1 در بخش ۱۱).

---
*پایان handover. سیکل بعدی از Phase 2 (BUILD) شروع می‌شود و به دسترسی portal/API یا drive-by data نیاز دارد.*
