// ============================================================
// CryptoQuant API v1 — On-Chain Data Scraper
// Personal Plan: 20 req/min → 3s تاخیر بین درخواست‌ها
// ============================================================

const BASE_URL = "https://api.cryptoquant.com/v1";
const DELAY_MS = 3100; // کمی بیشتر از ۳ ثانیه برای اطمینان

let allData = {
  meta: { fetchedAt: null, days: 0, totalRequests: 0, errors: [] },
  btc_ohlcv:     [],
  btc_inflow:    [],
  btc_outflow:   [],
  btc_reserve:   [],
  btc_ffr:       [],
  btc_mpi:       [],
  btc_nvt:       [],
  btc_tx:        [],
  btc_mvrv:      [],
  btc_miner_out: [],
  btc_oi:        [],
  btc_funding:   [],
  eth_ohlcv:     [],
  eth_inflow:    [],
  eth_outflow:   [],
  eth_reserve:   [],
};

let totalRequests = 0;
let doneRequests  = 0;
let abortFlag     = false;
let countdownTimer = null;

// ── فعلی sub-tab برای هر tab ──
const activeSubTab = { btc: "ohlcv", eth: "ohlcv" };

// ============================================================
// هسته: fetch با retry و مدیریت 429
// ============================================================
async function apiCall(path) {
  const token = document.getElementById("apiKey").value.trim();
  if (!token) throw new Error("Access Token وارد نشده!");
  if (abortFlag) throw new Error("ABORTED");

  const url = BASE_URL + path;

  for (let attempt = 1; attempt <= 3; attempt++) {
    if (abortFlag) throw new Error("ABORTED");
    try {
      const res = await fetch(url, {
        headers: { "Authorization": "Bearer " + token, "Accept": "application/json" }
      });

      if (res.status === 429) {
        const retryAfter = parseInt(res.headers.get("Retry-After") || "") || (15 * attempt);
        setStatus(`⏳ Rate limit 429 — ${retryAfter}s صبر...`);
        await sleepCountdown(retryAfter);
        continue;
      }
      if (res.status === 401) throw new Error("Token نامعتبر است (401)");
      if (res.status === 403) throw new Error("دسترسی مجاز نیست — این endpoint در پلن Personal پشتیبانی نمی‌شود (403)");
      if (!res.ok) {
        const body = await res.text().catch(() => res.statusText);
        throw new Error(`HTTP ${res.status}: ${body.slice(0, 120)}`);
      }

      const json = await res.json();
      const code = json?.status?.code;
      if (code !== undefined && code !== 0 && code !== 200) {
        throw new Error(`API error ${code}: ${json?.status?.message || "unknown"}`);
      }

      const rows = json?.result?.data ?? [];
      allData.meta.totalRequests++;
      doneRequests++;
      setProgress(Math.min(Math.round((doneRequests / totalRequests) * 100), 100));
      return Array.isArray(rows) ? rows : [];

    } catch (e) {
      if (e.message === "ABORTED" || e.message.includes("401")) throw e;
      if (attempt === 3) throw e;
      await sleep(3000);
    }
  }
  return [];
}

// ── sleep ساده ──
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── sleep با countdown در UI ──
async function sleepCountdown(secs) {
  clearInterval(countdownTimer);
  const el = document.getElementById("countdownText");
  let remaining = secs;
  el.textContent = `⏱ ${remaining}s`;
  return new Promise(resolve => {
    countdownTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(countdownTimer);
        el.textContent = "";
        resolve();
      } else {
        el.textContent = `⏱ ${remaining}s`;
      }
    }, 1000);
  });
}

// ── countdown بین درخواست‌های معمولی ──
async function waitBetween() {
  await sleepCountdown(Math.ceil(DELAY_MS / 1000));
  await sleep(DELAY_MS % 1000);
}

// ── helpers UI ──
function setStatus(msg) {
  document.getElementById("statusText").textContent = msg;
}
function setProgress(pct) {
  document.getElementById("progressFill").style.width = pct + "%";
  document.getElementById("progressCount").textContent =
    `${doneRequests} / ${totalRequests} درخواست`;
}

// ── log ──
function addLog(msg, type = "info") {
  const box = document.getElementById("logBox");
  const ts  = new Date().toLocaleTimeString("en", { hour12: false });
  const div = document.createElement("div");
  div.className = "log-" + type;
  div.textContent = `[${ts}] ${msg}`;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

// ── خطای جزئی به صورت chip ──
function addErrorChip(label, msg) {
  const row = document.getElementById("errorChips");
  const wrap = document.createElement("div");
  wrap.className = "tooltip-wrap";
  wrap.innerHTML = `<span class="chip chip-err">${esc(label)} ✕</span>
                    <span class="tip">${esc(msg)}</span>`;
  row.appendChild(wrap);
}

// ============================================================
// ساخت لیست endpoint‌ها بر اساس بازه و asset
// ============================================================
function buildEndpoints(days, asset) {
  const limit  = days;
  const from   = getFromDate(days);
  const q      = `window=day&limit=${limit}&from=${from}`;
  const qex    = q + "&exchange=all_exchange";

  const btcEndpoints = [
    { key: "btc_ohlcv",     label: "BTC · OHLCV",            path: `/btc/market-data/price-ohlcv?${q}` },
    { key: "btc_inflow",    label: "BTC · Exchange Inflow",   path: `/btc/exchange-flows/inflow?${qex}` },
    { key: "btc_outflow",   label: "BTC · Exchange Outflow",  path: `/btc/exchange-flows/outflow?${qex}` },
    { key: "btc_reserve",   label: "BTC · Exchange Reserve",  path: `/btc/exchange-flows/reserve?${qex}` },
    { key: "btc_ffr",       label: "BTC · Fund Flow Ratio",   path: `/btc/flow-indicator/fund-flow-ratio?${q}` },
    { key: "btc_mpi",       label: "BTC · MPI",               path: `/btc/flow-indicator/mpi?${q}` },
    { key: "btc_nvt",       label: "BTC · NVT",               path: `/btc/network-indicator/nvt?${q}` },
    { key: "btc_tx",        label: "BTC · Tx Count",          path: `/btc/network-data/transactions-count?${q}` },
    { key: "btc_mvrv",      label: "BTC · MVRV",              path: `/btc/market-indicator/mvrv?${q}` },
    { key: "btc_miner_out", label: "BTC · Miner Outflow",     path: `/btc/miner-flows/outflow?${q}` },
    { key: "btc_oi",        label: "BTC · Open Interest",     path: `/btc/market-data/open-interest?${q}` },
    { key: "btc_funding",   label: "BTC · Funding Rate",      path: `/btc/market-data/funding-rates?${qex}` },
  ];

  const ethEndpoints = [
    { key: "eth_ohlcv",   label: "ETH · OHLCV",            path: `/eth/market-data/price-ohlcv?${q}` },
    { key: "eth_inflow",  label: "ETH · Exchange Inflow",   path: `/eth/exchange-flows/inflow?${qex}` },
    { key: "eth_outflow", label: "ETH · Exchange Outflow",  path: `/eth/exchange-flows/outflow?${qex}` },
    { key: "eth_reserve", label: "ETH · Exchange Reserve",  path: `/eth/exchange-flows/reserve?${qex}` },
  ];

  if (asset === "btc") return btcEndpoints;
  if (asset === "eth") return ethEndpoints;
  return [...btcEndpoints, ...ethEndpoints];
}

function getFromDate(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

// ============================================================
// اعتبارسنجی Token
// ============================================================
async function validateToken() {
  setStatus("🔑 بررسی Token...");
  addLog("تست سلامت token...", "info");
  try {
    await apiCall("/btc/market-data/price-ohlcv?window=day&limit=1");
    addLog("Token معتبر است ✓", "ok");
    return true;
  } catch (e) {
    if (e.message.includes("401") || e.message.includes("نامعتبر")) {
      setStatus("❌ Token اشتباه است! لطفاً از cryptoquant.com/pro/settings/api کلید بگیرید.");
      addLog("Token نامعتبر: " + e.message, "err");
      return false;
    }
    throw e;
  }
}

// ============================================================
// تابع اصلی
// ============================================================
async function startFetch() {
  const token = document.getElementById("apiKey").value.trim();
  if (!token) { alert("❌ لطفاً Access Token را وارد کنید!"); return; }

  abortFlag    = false;
  doneRequests = 0;
  allData.meta.errors = [];
  document.getElementById("errorChips").innerHTML = "";
  document.getElementById("logBox").innerHTML     = "";

  const days      = parseInt(document.getElementById("daysSelect").value);
  const asset     = document.getElementById("assetSelect").value;
  const endpoints = buildEndpoints(days, asset);

  // +1 برای token test
  totalRequests = endpoints.length + 1;

  // reset data
  Object.keys(allData).forEach(k => { if (k !== "meta") allData[k] = []; });
  allData.meta = { fetchedAt: new Date().toISOString(), days, totalRequests: 0, errors: [] };

  document.getElementById("fetchBtn").disabled = true;
  document.getElementById("stopBtn").classList.remove("hidden");
  document.getElementById("statusBox").classList.remove("hidden");
  document.getElementById("resultsCard").classList.add("hidden");
  setProgress(0);
  setStatus(`🚀 شروع... (${endpoints.length} endpoint · ~${Math.ceil(endpoints.length * 3)}s)`);

  try {
    // اعتبارسنجی
    const valid = await validateToken();
    if (!valid || abortFlag) return;
    await waitBetween();

    // دریافت endpoint‌ها
    for (let i = 0; i < endpoints.length; i++) {
      if (abortFlag) { addLog("توقف توسط کاربر", "warn"); break; }
      const ep = endpoints[i];
      setStatus(`⟳ ${ep.label} (${i + 1}/${endpoints.length})`);
      addLog(`Fetching: ${ep.label}`, "info");
      try {
        const rows = await apiCall(ep.path);
        allData[ep.key] = rows;
        addLog(`${ep.label} → ${rows.length} ردیف ✓`, "ok");
      } catch (e) {
        if (e.message === "ABORTED") break;
        addLog(`خطا در ${ep.label}: ${e.message}`, "err");
        allData.meta.errors.push({ endpoint: ep.label, msg: e.message });
        addErrorChip(ep.label, e.message);
        allData[ep.key] = [];
      }

      // تاخیر ۳ ثانیه (نه بعد از آخرین)
      if (i < endpoints.length - 1 && !abortFlag) {
        await waitBetween();
      }
    }

    if (!abortFlag) {
      const errCount = allData.meta.errors.length;
      setStatus(errCount
        ? `✅ تمام شد — ${errCount} خطای جزئی (بالا قابل مشاهده است)`
        : "✅ همه داده‌ها با موفقیت دریافت شدند!"
      );
      setProgress(100);
      document.getElementById("countdownText").textContent = "";
      renderResults(days, asset);
    } else {
      setStatus("⛔ توسط کاربر متوقف شد.");
    }

  } catch (e) {
    if (e.message !== "ABORTED") setStatus("❌ خطا: " + e.message);
    else setStatus("⛔ توسط کاربر متوقف شد.");
  } finally {
    document.getElementById("fetchBtn").disabled = false;
    document.getElementById("stopBtn").classList.add("hidden");
    clearInterval(countdownTimer);
  }
}

function stopFetch() {
  abortFlag = true;
  clearInterval(countdownTimer);
  setStatus("⛔ در حال توقف...");
}

// ============================================================
// رندر نتایج
// ============================================================
function renderResults(days, asset) {
  document.getElementById("resultsCard").classList.remove("hidden");

  // آمار بالا
  const errHtml = allData.meta.errors.length
    ? `<div class="stat-chip error-chip" title="${allData.meta.errors.map(e=>e.endpoint+': '+e.msg).join('\n')}">⚠️ خطاها: <span>${allData.meta.errors.length}</span></div>`
    : "";
  document.getElementById("resultStats").innerHTML = `
    <div class="stat-chip">BTC rows: <span>${allData.btc_ohlcv.length}</span></div>
    <div class="stat-chip">ETH rows: <span>${allData.eth_ohlcv.length}</span></div>
    <div class="stat-chip">کل Requests: <span>${allData.meta.totalRequests}</span></div>
    <div class="stat-chip">بازه: <span>${days} روز</span></div>
    ${errHtml}
  `;

  renderBTCTab(days);
  renderETHTab(days);
  renderSignalTab();
}

// ── BTC ──
function renderBTCTab(days) {
  // OHLCV
  const ohlcv = [...allData.btc_ohlcv].reverse();
  document.getElementById("btcOhlcvBody").innerHTML = ohlcv.map(r => {
    const o = safeFloat(r.open_price ?? r.open);
    const c = safeFloat(r.close_price ?? r.close);
    const up = c !== null && o !== null && c >= o;
    return `<tr>
      <td>${esc(r.date ?? r.time ?? "—")}</td>
      <td>${fmtPrice(r.open_price ?? r.open)}</td>
      <td class="change-up">${fmtPrice(r.high_price ?? r.high)}</td>
      <td class="change-down">${fmtPrice(r.low_price ?? r.low)}</td>
      <td class="${up ? "change-up" : "change-down"}">${fmtPrice(r.close_price ?? r.close)}</td>
      <td>${fmtBig(r.volume)}</td>
    </tr>`;
  }).join("");

  // Flow
  const flowMap = buildFlowMap(allData.btc_inflow, allData.btc_outflow, allData.btc_reserve,
                               "inflow", "outflow", "reserve");
  document.getElementById("btcFlowBody").innerHTML = Object.keys(flowMap).sort().reverse().map(d => {
    const r = flowMap[d];
    const net = r.out !== null && r.in !== null ? r.out - r.in : null;
    return `<tr>
      <td>${esc(d)}</td>
      <td class="change-down">${fmtBig(r.in)}</td>
      <td class="change-up">${fmtBig(r.out)}</td>
      <td>${fmtBig(r.res)}</td>
      <td class="${net === null ? "" : net >= 0 ? "change-up" : "change-down"}">${net !== null ? (net >= 0 ? "+" : "") + fmtBig(net) : "—"}</td>
    </tr>`;
  }).join("");

  // Indicators
  const indMap = {};
  const addInd = (arr, field, label) => arr.forEach(r => {
    const d = r.date ?? r.time; if (!indMap[d]) indMap[d] = {};
    indMap[d][label] = safeFloat(r[field] ?? r.value);
  });
  addInd(allData.btc_mvrv,     "mvrv",              "MVRV");
  addInd(allData.btc_nvt,      "nvt",               "NVT");
  addInd(allData.btc_mpi,      "mpi",               "MPI");
  addInd(allData.btc_ffr,      "fund_flow_ratio",   "FFR");
  addInd(allData.btc_tx,       "transactions_count","TX");
  addInd(allData.btc_funding,  "funding_rates",     "FR");

  const mvrvBuy  = parseFloat(document.getElementById("mvrvBuy").value)  || 1;
  const mvrvSell = parseFloat(document.getElementById("mvrvSell").value) || 3.5;
  const nvtLow   = parseFloat(document.getElementById("nvtLow").value)   || 40;
  const nvtHigh  = parseFloat(document.getElementById("nvtHigh").value)  || 100;

  document.getElementById("btcIndBody").innerHTML = Object.keys(indMap).sort().reverse().map(d => {
    const r = indMap[d];
    const mvrvClass = r.MVRV !== null ? (r.MVRV < mvrvBuy ? "change-up" : r.MVRV > mvrvSell ? "change-down" : "") : "";
    const nvtClass  = r.NVT  !== null ? (r.NVT  < nvtLow  ? "change-up" : r.NVT  > nvtHigh  ? "change-down" : "") : "";
    const mpiClass  = r.MPI  !== null ? (r.MPI  < 0        ? "change-up" : "change-down") : "";
    return `<tr>
      <td>${esc(d)}</td>
      <td class="${mvrvClass}">${r.MVRV !== null ? r.MVRV.toFixed(3) : "—"}</td>
      <td class="${nvtClass}">${r.NVT  !== null ? r.NVT.toFixed(1)  : "—"}</td>
      <td class="${mpiClass}">${r.MPI  !== null ? r.MPI.toFixed(4)  : "—"}</td>
      <td>${r.FFR !== null ? r.FFR.toFixed(4) : "—"}</td>
      <td>${r.TX  !== null ? fmtBig(r.TX)     : "—"}</td>
      <td>${r.FR  !== null ? (r.FR * 100).toFixed(4) + "%" : "—"}</td>
    </tr>`;
  }).join("");
}

// ── ETH ──
function renderETHTab(days) {
  const ohlcv = [...allData.eth_ohlcv].reverse();
  document.getElementById("ethOhlcvBody").innerHTML = ohlcv.map(r => {
    const o = safeFloat(r.open_price ?? r.open);
    const c = safeFloat(r.close_price ?? r.close);
    const up = c !== null && o !== null && c >= o;
    return `<tr>
      <td>${esc(r.date ?? r.time ?? "—")}</td>
      <td>${fmtPrice(r.open_price ?? r.open)}</td>
      <td class="change-up">${fmtPrice(r.high_price ?? r.high)}</td>
      <td class="change-down">${fmtPrice(r.low_price ?? r.low)}</td>
      <td class="${up ? "change-up" : "change-down"}">${fmtPrice(r.close_price ?? r.close)}</td>
      <td>${fmtBig(r.volume)}</td>
    </tr>`;
  }).join("");

  const flowMap = buildFlowMap(allData.eth_inflow, allData.eth_outflow, allData.eth_reserve,
                               "inflow", "outflow", "reserve");
  document.getElementById("ethFlowBody").innerHTML = Object.keys(flowMap).sort().reverse().map(d => {
    const r = flowMap[d];
    const net = r.out !== null && r.in !== null ? r.out - r.in : null;
    return `<tr>
      <td>${esc(d)}</td>
      <td class="change-down">${fmtBig(r.in)}</td>
      <td class="change-up">${fmtBig(r.out)}</td>
      <td>${fmtBig(r.res)}</td>
      <td class="${net === null ? "" : net >= 0 ? "change-up" : "change-down"}">${net !== null ? (net >= 0 ? "+" : "") + fmtBig(net) : "—"}</td>
    </tr>`;
  }).join("");
}

// ── Signal ──
function renderSignalTab() {
  const mvrvBuy  = parseFloat(document.getElementById("mvrvBuy").value)  || 1;
  const mvrvSell = parseFloat(document.getElementById("mvrvSell").value) || 3.5;
  const nvtLow   = parseFloat(document.getElementById("nvtLow").value)   || 40;
  const nvtHigh  = parseFloat(document.getElementById("nvtHigh").value)  || 100;

  const last = (arr) => arr[arr.length - 1] || {};
  const prev8 = (arr) => arr[arr.length - 8] || {};

  const lastRes  = safeFloat((last(allData.btc_reserve)).reserve  ?? (last(allData.btc_reserve)).value);
  const prev8Res = safeFloat((prev8(allData.btc_reserve)).reserve ?? (prev8(allData.btc_reserve)).value);
  const resChg7  = lastRes && prev8Res ? ((lastRes - prev8Res) / prev8Res * 100) : null;

  const lastMpi     = safeFloat((last(allData.btc_mpi)).mpi);
  const lastNvt     = safeFloat((last(allData.btc_nvt)).nvt);
  const lastMvrv    = safeFloat((last(allData.btc_mvrv)).mvrv);
  const lastFunding = safeFloat((last(allData.btc_funding)).funding_rates ?? (last(allData.btc_funding)).value);
  const btcPrice    = safeFloat((last(allData.btc_ohlcv)).close_price ?? (last(allData.btc_ohlcv)).close);
  const ethPrice    = safeFloat((last(allData.eth_ohlcv)).close_price ?? (last(allData.eth_ohlcv)).close);

  // امتیازدهی
  let score = 0, reasons = [];

  // Exchange Reserve
  if (resChg7 !== null) {
    if (resChg7 < -2)      { score++; reasons.push({ s:"bull", t:`Exchange Reserve 7d: ${resChg7.toFixed(2)}% → کاهش ذخایر (صعودی)` }); }
    else if (resChg7 > 2)  { score--; reasons.push({ s:"bear", t:`Exchange Reserve 7d: ${resChg7.toFixed(2)}% → افزایش ذخایر (نزولی)` }); }
    else                   { reasons.push({ s:"neutral", t:`Exchange Reserve 7d: ${resChg7.toFixed(2)}% → خنثی` }); }
  }

  // MPI
  if (lastMpi !== null) {
    if (lastMpi < 0)  { score++; reasons.push({ s:"bull", t:`MPI = ${lastMpi.toFixed(4)} منفی → ماینرها نگه می‌دارند (صعودی)` }); }
    else              { score--; reasons.push({ s:"bear", t:`MPI = ${lastMpi.toFixed(4)} مثبت → ماینرها می‌فروشند (نزولی)` }); }
  }

  // NVT
  if (lastNvt !== null) {
    if (lastNvt < nvtLow)       { score++; reasons.push({ s:"bull", t:`NVT = ${lastNvt.toFixed(1)} (< ${nvtLow}) → Undervalued (صعودی)` }); }
    else if (lastNvt > nvtHigh) { score--; reasons.push({ s:"bear", t:`NVT = ${lastNvt.toFixed(1)} (> ${nvtHigh}) → Overvalued (نزولی)` }); }
    else                        { reasons.push({ s:"neutral", t:`NVT = ${lastNvt.toFixed(1)} → محدوده عادی` }); }
  }

  // MVRV
  if (lastMvrv !== null) {
    if (lastMvrv < mvrvBuy)       { score++; reasons.push({ s:"bull", t:`MVRV = ${lastMvrv.toFixed(3)} (< ${mvrvBuy}) → سیگنال خرید تاریخی` }); }
    else if (lastMvrv > mvrvSell) { score--; reasons.push({ s:"bear", t:`MVRV = ${lastMvrv.toFixed(3)} (> ${mvrvSell}) → ریسک توزیع بالا` }); }
    else                          { reasons.push({ s:"neutral", t:`MVRV = ${lastMvrv.toFixed(3)} → محدوده عادی` }); }
  }

  // Funding Rate
  if (lastFunding !== null) {
    if (lastFunding < 0)         { score++; reasons.push({ s:"bull", t:`Funding Rate = ${(lastFunding*100).toFixed(4)}% منفی → احتمال short squeeze` }); }
    else if (lastFunding > 0.0003){ score--; reasons.push({ s:"bear", t:`Funding Rate = ${(lastFunding*100).toFixed(4)}% بالا → over-leveraged` }); }
    else                         { reasons.push({ s:"neutral", t:`Funding Rate = ${(lastFunding*100).toFixed(4)}% → خنثی` }); }
  }

  // حکم نهایی
  let verdict, verdictClass, verdictEmoji;
  if      (score >= 4)  { verdict="STRONG BULLISH 🟢"; verdictClass="verdict-bull";  verdictEmoji="🚀"; }
  else if (score >= 2)  { verdict="BULLISH 🟡";         verdictClass="verdict-cbull"; verdictEmoji="📈"; }
  else if (score <= -4) { verdict="STRONG BEARISH 🔴";  verdictClass="verdict-bear";  verdictEmoji="🔻"; }
  else if (score <= -2) { verdict="BEARISH 🟠";          verdictClass="verdict-cbear"; verdictEmoji="📉"; }
  else                  { verdict="NEUTRAL ⚪";           verdictClass="verdict-neutral";verdictEmoji="⚖️"; }

  document.getElementById("verdictBox").innerHTML = `
    <div class="verdict-card ${verdictClass}">
      <div class="verdict-emoji">${verdictEmoji}</div>
      <div>
        <div class="verdict-title">${esc(verdict)}</div>
        <div class="verdict-score">امتیاز: ${score > 0 ? "+" : ""}${score} از ۵</div>
        <div class="chip-row" style="margin-top:10px">
          ${reasons.map(r => `<span class="chip chip-${r.s}">${esc(r.t)}</span>`).join("")}
        </div>
      </div>
    </div>`;

  // Signal Grid
  document.getElementById("signalGrid").innerHTML = [
    { name:"Exchange Reserve (7d)", val: resChg7!==null?resChg7.toFixed(2)+"%":"N/A",
      cls: resChg7!==null?(resChg7<-2?"sig-bull":resChg7>2?"sig-bear":"sig-neutral"):"sig-neutral",
      desc: resChg7!==null?(resChg7<-2?"کاهش = صعودی":resChg7>2?"افزایش = نزولی":"خنثی"):"داده موجود نیست" },
    { name:"MPI (Miner Position Index)", val: lastMpi!==null?lastMpi.toFixed(4):"N/A",
      cls: lastMpi!==null?(lastMpi<0?"sig-bull":"sig-bear"):"sig-neutral",
      desc: lastMpi!==null?(lastMpi<0?"ماینرها نگه می‌دارند":"ماینرها می‌فروشند"):"داده موجود نیست" },
    { name:"NVT Ratio", val: lastNvt!==null?lastNvt.toFixed(1):"N/A",
      cls: lastNvt!==null?(lastNvt<nvtLow?"sig-bull":lastNvt>nvtHigh?"sig-bear":"sig-neutral"):"sig-neutral",
      desc: lastNvt!==null?(lastNvt<nvtLow?"Undervalued":lastNvt>nvtHigh?"Overvalued":"عادی"):"داده موجود نیست" },
    { name:"MVRV Ratio", val: lastMvrv!==null?lastMvrv.toFixed(3):"N/A",
      cls: lastMvrv!==null?(lastMvrv<mvrvBuy?"sig-bull":lastMvrv>mvrvSell?"sig-bear":"sig-neutral"):"sig-neutral",
      desc: lastMvrv!==null?(lastMvrv<mvrvBuy?"زیر ارزش تحقق‌یافته":lastMvrv>mvrvSell?"ریسک توزیع":"عادی"):"داده موجود نیست" },
    { name:"Funding Rate", val: lastFunding!==null?(lastFunding*100).toFixed(4)+"%":"N/A",
      cls: lastFunding!==null?(lastFunding<0?"sig-bull":lastFunding>0.0003?"sig-bear":"sig-neutral"):"sig-neutral",
      desc: lastFunding!==null?(lastFunding<0?"Short squeeze احتمالی":lastFunding>0.0003?"Over-leveraged":"خنثی"):"داده موجود نیست" },
  ].map(s => `
    <div class="signal-item ${s.cls}">
      <div class="signal-name">${esc(s.name)}</div>
      <div class="signal-value">${esc(s.val)}</div>
      <div class="signal-desc">${esc(s.desc)}</div>
    </div>
  `).join("");

  // خلاصه جدول
  const rows = [
    ["BTC Price",        btcPrice  ? "$" + btcPrice.toLocaleString()  : "N/A"],
    ["ETH Price",        ethPrice  ? "$" + ethPrice.toLocaleString()  : "N/A"],
    ["MVRV",             lastMvrv  !== null ? lastMvrv.toFixed(3)     : "N/A"],
    ["NVT",              lastNvt   !== null ? lastNvt.toFixed(1)      : "N/A"],
    ["MPI",              lastMpi   !== null ? lastMpi.toFixed(4)      : "N/A"],
    ["Funding Rate",     lastFunding !== null ? (lastFunding*100).toFixed(4)+"%" : "N/A"],
    ["Exchange Reserve", lastRes   !== null ? fmtBig(lastRes) + " BTC" : "N/A"],
    ["Reserve 7d Change",resChg7   !== null ? resChg7.toFixed(2)+"%" : "N/A"],
    ["Open Interest",    fmtBig(safeFloat((last(allData.btc_oi)).open_interest ?? (last(allData.btc_oi)).value))],
    ["Miner Outflow",    fmtBig(safeFloat((last(allData.btc_miner_out)).outflow ?? (last(allData.btc_miner_out)).value))],
    ["سیگنال نهایی",     verdict],
    ["خطاها",            allData.meta.errors.length ? allData.meta.errors.length + " خطا" : "بدون خطا ✅"],
  ];
  document.getElementById("summaryBody").innerHTML = rows.map(([k, v]) => {
    const isBull = v && (v.includes("صعودی") || v.includes("BULLISH"));
    const isBear = v && (v.includes("نزولی") || v.includes("BEARISH"));
    return `<tr>
      <td>${esc(k)}</td>
      <td class="${isBull?"change-up":isBear?"change-down":""}">${esc(v ?? "—")}</td>
      <td>${isBull?"🟢 صعودی":isBear?"🔴 نزولی":"⚪"}</td>
    </tr>`;
  }).join("");
}

// ============================================================
// Tabs
// ============================================================
function showTab(name) {
  ["btc", "eth", "signal"].forEach(t => {
    document.getElementById("tab-" + t).classList.toggle("hidden", t !== name);
  });
  document.querySelectorAll(".tab").forEach((b, i) => {
    b.classList.toggle("active", ["btc", "eth", "signal"][i] === name);
  });
}

function showSubTab(parent, name, btn) {
  const panels = document.querySelectorAll(`[id^="${parent}-sub-"]`);
  panels.forEach(p => p.classList.toggle("hidden", !p.id.endsWith(name)));
  btn.closest(".sub-tabs").querySelectorAll(".sub-tab").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  activeSubTab[parent] = name;
}

// ============================================================
// Export
// ============================================================
function exportJSON() {
  downloadFile(
    JSON.stringify(allData, null, 2),
    "application/json",
    `cryptoquant_${dateStr()}.json`
  );
}

function exportCSV(asset) {
  const ohlcv = allData[`${asset}_ohlcv`];
  if (!ohlcv.length) { alert(`داده OHLCV برای ${asset.toUpperCase()} موجود نیست!`); return; }

  const headers = ["date", "open", "high", "low", "close", "volume"];
  const rows = ohlcv.map(r => [
    r.date ?? r.time ?? "",
    safeFloat(r.open_price  ?? r.open)  ?? "",
    safeFloat(r.high_price  ?? r.high)  ?? "",
    safeFloat(r.low_price   ?? r.low)   ?? "",
    safeFloat(r.close_price ?? r.close) ?? "",
    safeFloat(r.volume)                 ?? ""
  ].map(v => `"${v}"`).join(","));

  // بخش‌های اضافی
  let extra = "\n";
  if (asset === "btc") {
    const addSection = (label, arr, fields) => {
      if (!arr.length) return;
      extra += `\n# ${label}\n`;
      const hdrs = ["date", ...fields];
      extra += hdrs.join(",") + "\n";
      arr.forEach(r => {
        const vals = [r.date ?? r.time ?? "", ...fields.map(f => safeFloat(r[f] ?? r.value) ?? "")];
        extra += vals.map(v => `"${v}"`).join(",") + "\n";
      });
    };
    addSection("BTC_EXCHANGE_INFLOW",  allData.btc_inflow,  ["inflow_total", "inflow"]);
    addSection("BTC_EXCHANGE_OUTFLOW", allData.btc_outflow, ["outflow_total", "outflow"]);
    addSection("BTC_EXCHANGE_RESERVE", allData.btc_reserve, ["reserve"]);
    addSection("BTC_MVRV",   allData.btc_mvrv,    ["mvrv"]);
    addSection("BTC_NVT",    allData.btc_nvt,     ["nvt"]);
    addSection("BTC_MPI",    allData.btc_mpi,     ["mpi"]);
    addSection("BTC_FUNDING",allData.btc_funding, ["funding_rates"]);
  }

  const csv = [headers.join(","), ...rows].join("\n") + extra;
  downloadFile(csv, "text/csv;charset=utf-8;", `${asset.toUpperCase()}_onchain_${dateStr()}.csv`);
}

function exportAnalysis() {
  const last = (arr) => arr[arr.length - 1] || {};
  const lastRes  = safeFloat((last(allData.btc_reserve)).reserve  ?? (last(allData.btc_reserve)).value);
  const prev8Res = safeFloat((allData.btc_reserve[allData.btc_reserve.length - 8] || {}).reserve ?? "");
  const resChg7  = lastRes && prev8Res ? ((lastRes - prev8Res) / prev8Res * 100) : null;
  const lastMpi  = safeFloat((last(allData.btc_mpi)).mpi);
  const lastNvt  = safeFloat((last(allData.btc_nvt)).nvt);
  const lastMvrv = safeFloat((last(allData.btc_mvrv)).mvrv);
  const lastFund = safeFloat((last(allData.btc_funding)).funding_rates ?? (last(allData.btc_funding)).value);
  const btcPrice = safeFloat((last(allData.btc_ohlcv)).close_price ?? (last(allData.btc_ohlcv)).close);
  const ethPrice = safeFloat((last(allData.eth_ohlcv)).close_price ?? (last(allData.eth_ohlcv)).close);

  const mvrvBuy  = parseFloat(document.getElementById("mvrvBuy").value)  || 1;
  const mvrvSell = parseFloat(document.getElementById("mvrvSell").value) || 3.5;
  const nvtLow   = parseFloat(document.getElementById("nvtLow").value)   || 40;
  const nvtHigh  = parseFloat(document.getElementById("nvtHigh").value)  || 100;

  const bullSignals = [resChg7 < -2, lastMpi < 0, lastNvt < nvtLow, lastMvrv < mvrvBuy, lastFund < 0].filter(Boolean).length;
  const bearSignals = [resChg7 >  2, lastMpi > 0, lastNvt > nvtHigh, lastMvrv > mvrvSell, lastFund > 0.0003].filter(Boolean).length;
  const score = bullSignals - bearSignals;
  const sig = score >= 4 ? "STRONG BULLISH 🟢"
            : score >= 2 ? "BULLISH 🟡"
            : score <= -4 ? "STRONG BEARISH 🔴"
            : score <= -2 ? "BEARISH 🟠"
            : "NEUTRAL ⚪";

  const report = {
    generated_at: new Date().toISOString(),
    api: "CryptoQuant v1",
    plan: "Personal (20 req/min)",
    days: allData.meta.days,
    settings: { mvrvBuy, mvrvSell, nvtLow, nvtHigh },
    signal: {
      verdict: sig,
      score: `${score >= 0 ? "+" : ""}${score}`,
      bull_signals: bullSignals,
      bear_signals: bearSignals,
    },
    last_values: {
      btc_price:         btcPrice  ? "$" + btcPrice.toLocaleString() : "N/A",
      eth_price:         ethPrice  ? "$" + ethPrice.toLocaleString() : "N/A",
      mvrv:              lastMvrv  !== null ? lastMvrv.toFixed(3)    : "N/A",
      nvt:               lastNvt   !== null ? lastNvt.toFixed(1)     : "N/A",
      mpi:               lastMpi   !== null ? lastMpi.toFixed(4)     : "N/A",
      funding_rate_pct:  lastFund  !== null ? (lastFund*100).toFixed(4) + "%" : "N/A",
      exchange_reserve:  lastRes   !== null ? fmtBig(lastRes) + " BTC" : "N/A",
      reserve_7d_change: resChg7   !== null ? resChg7.toFixed(2) + "%" : "N/A",
    },
    reasons: [
      resChg7 !== null && (resChg7 < -2
        ? `[+] Exchange Reserve 7d: ${resChg7.toFixed(2)}% → کاهش ذخایر صعودی`
        : resChg7 > 2 ? `[-] Exchange Reserve 7d: ${resChg7.toFixed(2)}% → افزایش ذخایر نزولی` : null),
      lastMpi !== null && (lastMpi < 0
        ? `[+] MPI=${lastMpi.toFixed(4)} منفی → ماینرها نگه می‌دارند`
        : `[-] MPI=${lastMpi.toFixed(4)} مثبت → ماینرها می‌فروشند`),
      lastNvt !== null && (lastNvt < nvtLow
        ? `[+] NVT=${lastNvt.toFixed(1)} Undervalued`
        : lastNvt > nvtHigh ? `[-] NVT=${lastNvt.toFixed(1)} Overvalued` : null),
      lastMvrv !== null && (lastMvrv < mvrvBuy
        ? `[+] MVRV=${lastMvrv.toFixed(3)} خرید تاریخی`
        : lastMvrv > mvrvSell ? `[-] MVRV=${lastMvrv.toFixed(3)} ریسک توزیع` : null),
      lastFund !== null && (lastFund < 0
        ? `[+] Funding=${(lastFund*100).toFixed(4)}% احتمال short squeeze`
        : lastFund > 0.0003 ? `[-] Funding=${(lastFund*100).toFixed(4)}% over-leveraged` : null),
    ].filter(Boolean),
    errors: allData.meta.errors,
  };

  downloadFile(
    JSON.stringify(report, null, 2),
    "application/json",
    `cryptoquant_analysis_${dateStr()}.json`
  );
}

// ============================================================
// Utility
// ============================================================
function safeFloat(v, fallback = null) {
  if (v === null || v === undefined || v === "") return fallback;
  const n = parseFloat(String(v).replace(/,/g, ""));
  return isNaN(n) ? fallback : n;
}

function esc(s) {
  if (s == null) return "—";
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function fmtPrice(n) {
  const v = safeFloat(n);
  if (v === null) return "—";
  return "$" + v.toLocaleString("en", { maximumFractionDigits: 0 });
}

function fmtBig(n) {
  const v = safeFloat(n);
  if (v === null) return "—";
  if (Math.abs(v) >= 1e9)  return (v / 1e9).toFixed(2) + "B";
  if (Math.abs(v) >= 1e6)  return (v / 1e6).toFixed(2) + "M";
  if (Math.abs(v) >= 1e3)  return (v / 1e3).toFixed(1) + "K";
  return v.toFixed(2);
}

function buildFlowMap(inflowArr, outflowArr, reserveArr, inflowField, outflowField, reserveField) {
  const map = {};
  const set = (arr, field, key) => arr.forEach(r => {
    const d = r.date ?? r.time;
    if (!map[d]) map[d] = { in: null, out: null, res: null };
    map[d][key] = safeFloat(r[field] ?? r.value);
  });
  set(inflowArr,  inflowField,  "in");
  set(outflowArr, outflowField, "out");
  set(reserveArr, reserveField, "res");
  return map;
}

function downloadFile(content, type, filename) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = filename;
  a.click();
}

function dateStr() {
  return new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
}
