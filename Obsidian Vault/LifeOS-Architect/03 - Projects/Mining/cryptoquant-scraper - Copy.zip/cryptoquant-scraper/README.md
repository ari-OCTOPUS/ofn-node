# ⛓ CryptoQuant On-Chain Scraper

ابزار وب برای دریافت داده آنچین از **CryptoQuant API v1**
مخصوص پلن **Personal** (20 req/min · ۱ سال داده تاریخی · Personal use only)

---

## 📁 ساختار فایل‌ها

```
cryptoquant-scraper/
├── index.html   ← رابط کاربری (HTML)
├── app.js       ← منطق اصلی (fetch، signal، export)
├── style.css    ← استایل
└── README.md    ← این فایل
```

---

## 🚀 نحوه استفاده

1. پوشه را باز کنید و `index.html` را در مرورگر باز کنید
   *(نیازی به سرور ندارد — فایل محلی است)*

2. Access Token را از صفحه [cryptoquant.com/pro/settings/api](https://cryptoquant.com/pro/settings/api) بگیرید

3. بازه زمانی و asset انتخاب کنید

4. روی **🚀 شروع دریافت داده** کلیک کنید

5. پس از اتمام، داده را Export کنید

---

## ⚙️ پارامترهای API

| پارامتر | مقدار |
|---------|-------|
| Base URL | `https://api.cryptoquant.com/v1` |
| Auth | `Authorization: Bearer <token>` |
| Rate Limit | 20 req/min |
| تاخیر بین درخواست‌ها | ۳.۱ ثانیه |
| window | `day` |
| حداکثر limit | `365` |

---

## 📊 Endpoint‌ها

### BTC (12 endpoint)
| کلید | مسیر | توضیح |
|------|------|-------|
| btc_ohlcv | `/btc/market-data/price-ohlcv` | قیمت OHLCV |
| btc_inflow | `/btc/exchange-flows/inflow` | ورود به صرافی |
| btc_outflow | `/btc/exchange-flows/outflow` | خروج از صرافی |
| btc_reserve | `/btc/exchange-flows/reserve` | ذخایر صرافی |
| btc_ffr | `/btc/flow-indicator/fund-flow-ratio` | نسبت جریان |
| btc_mpi | `/btc/flow-indicator/mpi` | Miner Position Index |
| btc_nvt | `/btc/network-indicator/nvt` | NVT Ratio |
| btc_tx | `/btc/network-data/transactions-count` | تعداد تراکنش |
| btc_mvrv | `/btc/market-indicator/mvrv` | MVRV Ratio |
| btc_miner_out | `/btc/miner-flows/outflow` | خروج ماینرها |
| btc_oi | `/btc/market-data/open-interest` | Open Interest |
| btc_funding | `/btc/market-data/funding-rates` | Funding Rate |

### ETH (4 endpoint)
| کلید | مسیر | توضیح |
|------|------|-------|
| eth_ohlcv | `/eth/market-data/price-ohlcv` | قیمت OHLCV |
| eth_inflow | `/eth/exchange-flows/inflow` | ورود به صرافی |
| eth_outflow | `/eth/exchange-flows/outflow` | خروج از صرافی |
| eth_reserve | `/eth/exchange-flows/reserve` | ذخایر صرافی |

---

## ⚡ سیگنال معاملاتی

سیگنال بر اساس **۵ فاکتور** امتیازدهی می‌شود:

| فاکتور | صعودی | نزولی |
|--------|-------|-------|
| Exchange Reserve (7d) | کاهش < -2% | افزایش > +2% |
| MPI | < 0 (ماینر نگه می‌دارد) | > 0 (ماینر می‌فروشد) |
| NVT | < 40 (Undervalued) | > 100 (Overvalued) |
| MVRV | < 1 (خرید تاریخی) | > 3.5 (ریسک توزیع) |
| Funding Rate | منفی (short squeeze) | > 0.03% (over-leveraged) |

**امتیاز نهایی:**
- `+4` یا بیشتر → STRONG BULLISH 🟢
- `+2` تا `+3` → BULLISH 🟡
- `0` تا `+1` / `-1` → NEUTRAL ⚪
- `-2` تا `-3` → BEARISH 🟠
- `-4` یا کمتر → STRONG BEARISH 🔴

---

## 💾 خروجی‌ها

| فایل | محتوا |
|------|-------|
| `cryptoquant_YYYY-MM-DD.json` | همه داده‌های خام |
| `BTC_onchain_YYYY-MM-DD.csv` | OHLCV + همه شاخص‌های BTC |
| `ETH_onchain_YYYY-MM-DD.csv` | OHLCV + Exchange Flow اتریوم |
| `cryptoquant_analysis_YYYY-MM-DD.json` | سیگنال نهایی + دلایل |

---

## ⏱ زمان تقریبی

| حالت | تعداد Request | زمان |
|------|---------------|------|
| BTC + ETH (هر دو) | 17 | ~52 ثانیه |
| فقط BTC | 13 | ~39 ثانیه |
| فقط ETH | 5 | ~15 ثانیه |

---

## ⚠️ محدودیت‌ها

- پلن Personal فقط برای **استفاده شخصی** مجاز است
- داده تاریخی حداکثر **۱ سال** است
- اگر endpoint‌ای خطای **403** داد، آن شاخص در پلن شما موجود نیست
- فایل‌ها را می‌توان به **Claude** آپلود کرد تا تحلیل عمیق‌تری انجام دهد

---

## 🔧 توسعه

برای اضافه‌کردن endpoint جدید در `app.js`:

```javascript
// در تابع buildEndpoints()
{ key: "btc_new", label: "BTC · New Indicator", path: `/btc/new-path?${q}` }
```

و در `allData`:
```javascript
btc_new: [],
```
