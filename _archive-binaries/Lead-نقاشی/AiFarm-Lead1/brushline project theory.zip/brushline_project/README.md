# Brushline — Theory Project (README)

> سیستمِ چندایجنتیِ marketing/lead-gen برای نقاشیِ ساختمانِ سیدنی. این bundle = **کلِ لایهٔ تئوری** (بدونِ کد). نقطهٔ شروع برای کدنویسی (فاز ۰).

## از کجا شروع کنم؟
۱. **`00_governance/PROJECT_MANIFEST.md`** — فهرستِ کامل + گیتِ آمادگیِ پیش‌از‌کد. اول این.
۲. **`00_governance/BLUEPRINT.md`** — معماری و تصمیم‌های قفل.
۳. **`00_governance/ROADMAP.md`** — فازها + DoD.
۴. **`10_knowledge_base/KB-00_master_synthesis.md`** — نقشهٔ متصلِ همهٔ ماژول‌ها.

## ساختار
```
00_governance/   PROJECT_MANIFEST, BLUEPRINT, ROADMAP, CLAUDE_PROJECT_SETUP, GLOSSARY, CONFIG_parameters
10_knowledge_base/ KB-00 … KB-14
20_specs/        MVP_system_requirements, THREAT_MODEL
30_process/      BRUSHLINE_theory_completion_prompt, CONSISTENCY_REPORT, DEEP_RESEARCH_PROMPT
90_reference/    LANGAR refs + fusion checklist (آپلودِ جدا)
```

## سه Invariant (روحِ پروژه)
- **INV-1** هیچ publish/spend/پیام بدونِ human approval.
- **INV-2** PII/مالی هرگز در LANGAR/memory؛ داده در AU.
- **INV-3** auto-execution = kill switch + spend cap + hash-chained audit.

## وضعیت
لایهٔ تئوری **کامل و سازگار** (۲۱ سندِ markdown). تنها بازماندهٔ پیش‌از‌کد = ورودیِ Operator:
- CONFIG: `fx_aud_usd`، Google Places per-request، `spam_penalty_units` (verify).
- KB-02: `avg_margin_per_job`، `enquiry→quote`، `quote→job`.

با بسته‌شدنِ این‌ها → شروعِ **فاز ۰ (scaffold/reuse)**.

## مباحثی که تحقیقِ عمیق‌تر می‌خواهند
به `30_process/DEEP_RESEARCH_PROMPT.md` مراجعه کن (حقوقِ AU، APIهای واقعی، دادهٔ بازارِ محلی، LANGAR، go-to-market).

## قاعده‌ها
نام‌ها فقط از GLOSSARY؛ پارامترها فقط از CONFIG؛ همه‌چیز Markdown + Mermaid، بدونِ کد تا فاز ۰.
