# KNOWLEDGE_GRAPH — گرافِ دانشِ typed-edge (Wall-4-safe)

> **قاعده‌ی گراف:** هر یال یک **نوع** دارد (🔗 واقعی · 🌀 استعاری · ⚠️ ضعیف/هم‌نامی · 【P/S/E】 canon).
> هرگز «validated/inspired» به‌عنوانِ factِ لخت ادعا نمی‌شود؛ «validated» فقط برای یالِ 🔗 با شاهدِ صریح.
> در این corpus تقریباً هیچ یالِ «X validated Y» به‌معنای empirical وجود ندارد — بیشترِ یال‌ها 🔗 (اتصالِ منطقی)، 🌀 (استعاری) یا ⚠️ (هم‌نامی)‌اند.

---

## ۱. گرافِ ستونِ علمی (research nodes)

```
                         [G0 Wall 4] ──governs──► همه‌ی گره‌ها
                              │
[P0 قاب‌بندی] ──🔗 راستی‌آزماییِ منابع──► [P1 مکانیزم]
     │  🔗 تعریفِ عمق = لنگرِ دسته‌بندی           │ 🔗 Rainville/ACC (قوی‌ترین یال، A)
     ├────────────────────────────► [P2 روش]     │ 🔗 Jiang/ECN–DMN decoupling (B, تک‌مطالعه)
     │                                 │          │ ⚠️ theta/alpha/gamma (رد به‌عنوان مارکر)
     └──🔗 absorption/susceptibility──► [P3 استعداد]│ 💭 cold-control/predictive-coding
                                        ▲          │
        [P2 روش] ──🔗 «trait > method»──┘          │
        [P3] ──🔗 traitِ پایدار با امضای ECN–DMN همبسته──┘
```

**یال‌های کلیدیِ ستونِ علمی**

| از | به | نوع | گزاره |
|----|----|-----|-------|
| P0 | P1 | 🔗 | منابعِ to-verify در P1 web-verified شدند |
| P2(Braffman&Kirsch) | P3 | 🔗 | چون induction اثرِ کوچک دارد، تمرکز از method به predictor منتقل شد |
| P3(trait) | P2b | 🔗 | trait یک **سقف** می‌گذارد → customization = تطبیق با شخص |
| absorption هیپنوتیک | ECN–DMN decoupling | 🔗 | همبسته‌ی عصبیِ اندازه‌گیری‌شده (Jiang) |
| درد عاطفی | ACC | 🔗 | Rainville؛ قوی‌ترین و بازتولیدشده‌ترین |
| «coherence/همفازی» | مکانیزمِ عصبی | ⚠️ | **هم‌نامی!** امضا decoupling است، نه phase-lock |
| «گامای کوانتومی» | آگاهیِ هیپنوتیک | ⚠️ | شاهدِ EEG ضعیف/overstated → رد |
| COMT | hypnotizability | ⚠️ | replication-failure |
| NLP rep-system matching | customization | ⚠️ | شبه‌علم (Sharpley) — از شبکه بیرون |
| CSTP | «عمقِ آموختنی» | 💭 | مناقشه (compliance؟) |

---

## ۲. زیرگرافِ سنتز و canon

```
[STAGE2 مدلِ ۶لایه] ──🌀D── فرمولِ ضربیِ نهایی (استعاری، نه کمّی)
      │
      ├─🔗 لایه‌های ۱–۳ (عصبی/روانی/رفتاری): A/B، مکانیزمِ علمی
      ├─🔗 لایه ۴ (اجتماعی/entrainment): A مکانیزم / C اختصاصیِ MJ
      ├─🌀D لایه ۵ (زرتشتی: Aša/Druj/Ahriman) : نگاشتِ نمادین، نه ایران‌شناسی/فیزیک
      └─🌀D لایه ۶ (فنر/کوراموتو/لیزر/کوانتوم): فیزیک A / نگاشت به روان D

[X1] ── دوختِ واقعی↔فیوژن ──►
      دنیای واقعی 🔬 ── decoupling/trait/expectancy ──┐
                                                     ├─🌀【S】 نگاشتِ ساختاری (با مرز)
      دنیای فیوژن 【P】 ── seam/entanglement ──────────┘
              └─⚠️ no-comm theorem + هم‌نامیِ coherence = دو دیوارِ سخت

[C1 همتاب]──[C2 عبور از آستانه]──[C3 blueprint]──[C4 setup]   ← بدنه `[gap]`، فقط اسکلت
```

**یال‌های کلیدیِ سنتز/canon**

| از | به | نوع | گزاره |
|----|----|-----|-------|
| P1(decoupling) | STAGE2(«همفازی») | ⚠️→🔗 | تصحیح: امضای فردی decoupling است؛ STAGE2 باید disambiguate شود |
| seam(entanglement) | «هیپنوتیزمِ بین‌جهانی» | ⚠️ | no-communication theorem آن را می‌بندد 【E】 |
| «بازکوکِ prior» | «بازخوانیِ گذشته‌ی مشترک» | 🌀【S】 | نگاشتِ ساختاریِ مجاز با مرز |
| STAGE2 فرمول | معادله‌ی کمّی | ⚠️ | ضرب فیزیکاً تعریف‌نشده؛ فقط ابزارِ فهم |

---

## ۳. زیرگرافِ **pivotها / خودتصحیح‌ها** (رکوردِ تکامل — حذف نشود)

> ari-prompt می‌خواست «duplicateها» را پاک کند و «فقط بهترین نسخه» بماند. اینجا برعکس: این
> pivotها **همان پیشرفتِ فکری‌اند** و به‌عنوان یالِ زمانی حفظ می‌شوند.

| # | از (نسخه‌ی قدیم) | به (نسخه‌ی اصلاح‌شده) | محرک | provenance |
|---|------------------|----------------------|------|-----------|
| ۱ | phase-lock/«همه سینک می‌شود» | **decoupling** (ECN از DMN جدا) | Jiang؛ رد theta/gamma | file:P1 §1.4/1.5، file:X1 |
| ۲ | «عمیق‌ترین روشِ induction» | **trait + expectancy > method** | Braffman & Kirsch | file:P2، file:P3 |
| ۳ | ذهن/همدوسیِ کوانتومی به‌عنوان مکانیزم | رد بر پایه‌ی decoherence؛ کوانتوم فقط استعاره | Tegmark؛ Duan 2017 | file:STAGE2، file:_ |
| ۴ | «coherence» یکپارچه | هم‌نامیِ load-bearing؛ فردی(decoupling/release) ≠ گروهی(entrainment/sync) | P1/X1 | file:P1، file:X1، (بازنویسی روی افق) |
| ۵ | «هرکس را می‌شود به هر عمقی برد» | trait یک **سقف** است | Piccione؛ COMT رد | file:P3، file:P2b |
| — | *[project-memory]* Seam-as-operator نه substance؛ reduction به Π framework | `[not in corpus — memory-only]` | | project-memory |

---

## ۴. راهنمای خواندنِ گراف
- **🔗** = اتصالِ واقعی: یا شاهدِ empirical مشترک، یا اتصالِ منطقیِ مستقیم بینِ گره‌ها.
- **🌀** = استعاری: پلِ شهودی/ساختاری، نه این‌همانیِ فیزیکی. مجاز اگر صریح علامت بخورد.
- **⚠️** = ضعیف/هم‌نامی: وسوسه‌انگیز ولی احتمالاً مغالطه‌ی equivocation؛ یا شاهدِ رد/replication-failure.
- **【E/S/P】** = لایه‌ی canon: فیزیکِ established / گمانه / روایت.
