# EXTRACTION_REPORT — گزارشِ نهایی (صادقانه‌ی محدود)

## totals (فقط چیزِ inspectable — بدونِ فبریکِ عدد)
- **فایل‌های در دسترسِ Project:** ۱۵ (۷ markdown/متن + ۶ «PDF»‌ـِ‌ZIP + ۱ duplicate + پوشه).
- **فایل‌های تمیزِ خوانده‌شده:** ۹.
- **آرشیوهای استخراج‌شده با بدنه‌ی [gap]:** ۵.
- **duplicate:** ۱ (STAGE2 .pdf == .md).
- **گره‌های استخراج‌شده:** ۱۷ (G0–G1, P0–P3+P2b, X1, STAGE2, C1–C4, PR1–PR3) + ۴ گرهِ [gap]/memory-only.
- **پرامپت‌های کاتالوگ‌شده:** ۳.
- **pivot/self-correction ثبت‌شده:** ۵ (file-grounded) + ۱ (memory-only).
- **فرضیه‌ی falsifiableِ صریح در corpus:** ۰ در فایل‌های حاضر (spacing×expectancy فقط در project-memory).
- **⚠️ Total conversations analyzed / theories / experiments:** **قابلِ محاسبه‌ی صادقانه نیست** — من فقط فایل‌های Project + memory را می‌بینم، نه raw chat history. تولیدِ این اعداد نقضِ Wall 4 بود؛ عمداً انجام نشد.

## چه merge/dedup شد
- STAGE2 .pdf و .md یکی تشخیص داده شد؛ .md مرجع، .pdf archive. **محتوا ادغام نشد** (خطرِ آمیختنِ نسخه‌ها نبود چون یکی بودند).
- هیچ گرهِ دیگری merge نشد؛ هر فایل یک گرهِ مجزا با provenanceِ خودش ماند (بر خلافِ «merge into one coherent document»ِ ari-prompt، که reconstruction بود).

## Wall-4 compliance
- ✅ هر ادعا تگِ شواهد + provenance دارد.
- ✅ یال‌ها typed (🔗/🌀/⚠️)؛ هیچ «validated»ِ لخت.
- ✅ بدنه‌ی PDFهای خراب `[gap]` خورد، بازسازی نشد.
- ✅ attributionِ مشکوک (نامِ هیپنوتیزم‌گرِ تایسون) به‌عنوان ⚠️ to-verify علامت خورد، نه fact.
- ✅ register دوگانه: file-grounded ↔ memory-only جدا.
- ✅ عددِ conversation فبریک نشد.

## چه انجام **نشد** (و چرا)
- ❌ reconstructionِ بدنه‌ی canonِ خراب — نقضِ Wall 4.
- ❌ ادغامِ workstreamها (mining/marketing/canon) — نقضِ firewall.
- ❌ حذفِ «duplicate»ها به‌معنای پاک‌کردنِ pivotها — رکوردِ تکامل باید بماند.
- ❌ ساختِ پوشه‌های ۰۱_AI…۱۷_Archive — این corpus آن حوزه‌ها (mining/robotics/…) را ندارد؛ پوشه‌ی خالی ساختن گمراه‌کننده بود.

## confidence assessment
- **بالا:** استخراجِ ۹ فایلِ تمیز و تگ‌گذاری‌شان (متنِ اصلی خوانده شد).
- **متوسط:** اسکلتِ ۵ آرشیوِ خراب (فقط termهای انگلیسی/تگ‌ها/سرفصل‌های خوانا قابلِ اعتماد؛ بدنه نامعلوم).
- **پایین/معلق:** هر چیزی که فقط در project-memory است و در corpus نیست (Π/Seam، Layer 0/1/2، spacing×expectancy، Cardew، خروجی‌های استخراجِ قبلی) — به‌عنوان `[not in corpus]` علامت خورد، نه به‌عنوان دانشِ تأییدشده.

## قدمِ بعدیِ پیشنهادی
1. صادرِ مجددِ ۵ آرشیوِ خراب با encodingِ سالم تا از `[gap]` خارج شوند (بیشترین بازده).
2. یا: قفلِ رسمیِ **G0/Wall 4** به‌عنوان گرهِ حاکمیتی (اگر اولویت governance است).
3. یا: افزودنِ فایل‌های غایبِ P4/P5 اگر موجودند.
