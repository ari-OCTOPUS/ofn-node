# KNOWLEDGE_CORE — استخراجِ Wall-4-safe از corpusِ پروژه‌ی Fusion World

> **حالتِ استخراج:** guardrailed (گزینه‌ی ب). هر گره تگِ شواهد + provenance دارد؛ هیچ
> reconstruction/gap-filling انجام نشده؛ جایی که منبع ساکت یا خراب است `[gap]` خورده.
> **تگِ شواهد:** 🔬 established · 💭 مناقشه‌برانگیز/تازه · 🌀 استعاره — درجه‌ها A–E (کلیدِ STAGE2).
> **تگِ اتصال:** 🔗 واقعی · 🌀 استعاری · ⚠️ ضعیف/هم‌نامی.
> **تگِ canon:** 【E】 فیزیکِ established · 【S】 نگاشتِ گمانه‌ای · 【P】 روایت/canon.
> **provenance ≠ evidence:** «file:X» یعنی این ادعا در آن فایل هست — نه این‌که آن ادعا صحیح/تأییدشده است (Wall 4).

---

## G — گره‌های حاکمیتی (Governance)

### G0 · Wall 4 و چهار دیوار — قلبِ معرفتیِ پروژه
- **توضیح:** مجموعه‌ی قواعدی که «علم» را از «شعر» جدا نگه می‌دارد. Wall 4 = **Evidence ≠ Derivation**: خروجیِ استدلالیِ AI هرگز نباید به‌عنوان داده‌ی empirical تلقی شود.
- **قواعدِ سخت (از corpus):** metaphor ≠ mechanism؛ narrative ≠ data؛ «فقط اشتراکِ یک کلمه (موج، فروپاشی، همفازی، دوگانگی) دو حوزه را یکی نمی‌کند» (file:علم_عمیق §قانون طلایی)؛ «هیچ ادعای قطعی بدون منبع» (file:P0).
- **provenance:** file:علم_عمیق (قانون طلایی + سه‌گانه‌ی اتصال)؛ file:P0 (redline علم/lore)؛ file:_ (نقدِ بنیادینِ equivocation که این معماری را زاد).
- **status:** فعال؛ «تثبیتِ Wall 4 به‌عنوان گرهِ حاکمیتیِ رسمی» در project-memory روی افق است — **این فایلِ حاکمیتیِ رسمی هنوز در corpus نیست** `[gap]`.
- **risk:** self-sealing loop — استدلالِ AI که به داده بدل شود. بالاترین ریسکِ جاریِ پروژه (project-memory).

### G1 · Scope و firewallها
- **توضیح:** سه workstream با دیوارِ سخت: (۱) research (هیپنوتیزمِ واقعی، P0–X1)، (۲) canon/【P】 (Fusion World)، (۳) commercial/**ATELIER** (مارکتینگ). ادغام‌شان ممنوع.
- **دامنه‌ی مجاز:** فقط هیپنوتیزمِ **consensual و clinically-grounded** (education). covert influence و recovered-memory صریحاً بیرون (file:P0 §0.3؛ project-memory).
- **provenance:** file:P0 §0.3؛ file:X1 (مرزِ canon/واقعی)؛ file:CLAUDE_PROJECT_SETUP (ATELIER، جداییِ knowledge/instructions) — **بدنه‌ی این PDF غالباً `[gap]` (font-encoding)**.
- **status:** فعال.

---

## P — گره‌های research (هیپنوتیزمِ دنیای واقعی) — ستونِ علمی

### P0 · Scope & Epistemic Guardrails
- **توضیح:** زمین را قبل از تحقیق صاف می‌کند — محتوا تولید نمی‌کند.
- **یافته‌های کلیدی:**
  - «عمق» یک هم‌نامیِ ۵-معنایی است (behavioral suggestibility / subjective / neural / dissociation / absorption)؛ **لنگر = behavioral suggestibility (مقیاس‌های استاندارد)** 🔬. بقیه ثانویه.
  - سه لنزِ **رقیب** (نه مکمل): state/non-state (sociocognitive) · neo-dissociation (Hilgard) · predictive-processing/cold-control.
  - redline: 🔬 علم (traitِ پایدار، مقیاس‌ها، hypnoanalgesia، IBS) / اجماعِ بالینی / ⚠️ فولک‌مارکتینگ (شوک‌induction، mind-control، recovered-memory).
- **status:** بسته؛ منابعش در P1 راستی‌آزمایی شد.
- **provenance:** file:P0.

### P1 · Mechanism Map (نوروساینسِ established) — web-verified
- **مدارِ درد 🔬A:** Rainville et al. 1997 (Science, PET) — suggestion بُعدِ **عاطفیِ** درد (ACC) را مستقل از شدتِ حسی (S1) جابه‌جا می‌کند. قوی‌ترین و بازتولیدشده‌ترین یالِ حوزه؛ پایه‌ی hypnoanalgesia.
- **سه‌شبکه 🔬B (تک‌مطالعه):** Jiang et al. 2017 (Cereb Cortex) — کاهشِ dorsal-ACC؛ افزایشِ DLPFC–insula؛ **کاهشِ DLPFC(ECN)–PCC(DMN) = decoupling**. ⚠️ replicationِ مستقل محدود.
- **DMN/induction 🔬/💭:** McGeown؛ مرورِ مرجع Oakley & Halligan 2013 (Nat Rev Neurosci).
- **نوسانات ⚠️:** theta به‌عنوان مارکرِ حالت **رد شد** (Heliyon 2021؛ احتمالاً drowsiness)؛ alpha عمدتاً relaxation/چشم‌بسته؛ gamma مختلط و ترجمه‌ی intracranial→scalp پرخطر.
- **قابِ تازه 💭:** cold control (Dienes & Perner 2007) + predictive-coding (Martin & Pacherie 2019): suggestion یک priorِ non-agency تزریق می‌کند؛ مسئله precision-weighting است.
- **تصحیحِ محوری:** امضای عصبیِ عمق = **decoupling**، نه phase-locking → «coherence» را باید بازتعریف کرد (جدا‌شدنِ زیرسیستم، نه قفلِ فازِ سراسری).
- **provenance:** file:P1. **status:** web-verified.

### P2 · Method Taxonomy — web-verified
- **یافته‌ی قاب‌زننده 🔬:** Braffman & Kirsch — induction «کمِ کم» اضافه می‌کند؛ suggestibilityِ هیپنوتیک/غیرهیپنوتیک به‌شدت همبسته؛ تفاوت‌ها را nonhypnotic suggestibility + expectancy + motivation کامل توضیح می‌دهد.
- **پیامد 🔗:** «عمیق‌ترین روشِ induction» تا حد زیادی **سؤالِ غلط** است؛ متغیرِ غالب trait + expectancy است (→ P3)، نه روش.
- **جدولِ روش‌ها:** eye-fixation، progressive relaxation (relaxation **لازم نیست** — alert-hypnosis هم هست)، Elman/rapid، Ericksonian (indirect>direct شاهدِ مختلط 💭)، instant/shock (⚠️ compliance+expectancy)، fractionation/deepening (💭)، self-hypnosis.
- **provenance:** file:P2.

### P2b · Customization — web-verified
- **اصل:** چون method < trait+expectancy، customization = **تطبیق با شخص**، نه تکنیکِ جادویی.
- **محورها:** (۰) اول بسنج (SHSS:C/HGSHS:A/Elkins؛ ~۱۰–۱۵٪ high) · (۱) تطبیق با سطح؛ trait یک **سقف** است · (۲) permissive معمولاً بهتر، ولی وابسته به شخصیت · (۳) **Utilization** (اریکسون) = قلبِ شخصی‌سازی · (۴) imageryِ tailored 💭 امیدوارکننده · (۵) **expectancy/rapport = پُراهرم‌ترین** 🔬 · (۶) مودالیته (alert/relaxation) · (۷) self-hypnosis→P5.
- **⚠️ رد (شبه‌علم):** NLP preferred-representational-system / predicate-matching / eye-accessing-cues — Sharpley 1984 (۱۵ مطالعه، شاهدِ ناچیز، r<0.3)؛ Heap: «هیچ‌وقت substance نداشت».
- **provenance:** file:P2b.

### P3 · Susceptibility & Depth Predictors — web-verified
- **traitِ پایدار 🔬:** Piccione, Hilgard & Zimbardo 1989 — .64(۱۰y)/.82(۱۵y)/**.71(۲۵y)**، در حدِ IQ. ⭐ولی overstate نکن: test–retestِ یک‌هفته‌ای فقط متوسط (rs≈.66) با افتِ نمره (۲۰۲۱).
- **پیش‌بین‌ها:** expectancy 🔬 قوی‌ترین دست‌کاری‌پذیر · absorption 🔬 ولی **کوچک** · imaginative suggestibility 🔬 قوی · dissociation 💭 ضعیف · executive/frontal 💭 مختلط.
- **⚠️ ژنتیک:** COMT Val158Met — Szekely 2010 گزارش داد، **replication شکست خورد** (۲۰۱۳، N≈۲۵۳ هیچ اثرِ اصلی). «ژنِ هیپنوتیزم‌پذیری» رد.
- **💭 آموختنی بودنِ عمق:** CSTP (Spanos) نمره را بالا می‌برد — ولی منتقدان: احتمالاً compliance/گزارشِ ذهنی، نه traitِ واقعی. بستگی به objective/subjective دارد (→P0).
- **provenance:** file:P3.

### X1 · هیپنوتیزمِ واقعی × هیپنوتیزمِ فیوژن (cross-domain)
- **سه نتیجه‌ی صادقانه:**
  1. ⚠️ **بزرگ‌ترین تله:** «coherence» در دو دنیا دو چیز است — واقعی = decoupling؛ بریجِ «coherenceِ هیپنوتیک ↔ quantum coherence» فقط لفظی.
  2. حتی در canون، «هیپنوتیزم از روی seam» ممنوع است: **no-communication theorem 【E】** (ρ_B=I/2, mutual info صفر) — هیپنوتیزم ذاتاً کانالِ پیام (کلمه) می‌خواهد.
  3. پدیده‌ی واقعی به هیچ کوانتومی نیاز ندارد (P1–P3 + Tegmark decoherence).
- **نگاشتِ مجاز 🌀【S】 (با مرز):** «هیپنوتیزم = بازکوکِ priorهای عامل» ↔ «seam = گذشته‌ی علّیِ مشترکِ قابلِ بازخوانی». تشبیهِ ساختاریِ خوب، نه این‌همانی.
- **هشدارِ خودِ فایل:** در فایل‌های Fusion World **هیچ سندِ canonِ هیپنوتیزم نیست**؛ سمتِ فیوژن یک ساختِ 【P】 علامت‌دار است، نه canonِ موجود.
- **provenance:** file:X1.

> **[gap] گره‌های ارجاع‌شده ولی غایب از corpus:** **P4** (یال‌های cross-domain به flow/تایسون/جکسون) و **P5** (پروتکلِ اپراتور/self-hypnosis) در P0/P1/P3/P2b ارجاع شده‌اند اما فایلشان اینجا نیست.

---

## S — گرهِ سنتز

### STAGE2 · «مدلِ همفازیِ قدرت و رهاییِ فنری» (Phase-Locked Power & Spring-Release)
- **توضیح:** سنتزِ میان‌رشته‌ای (دامیاتو/تایسون، جکسون، مغز، فیزیکِ فنر/کوراموتو/لیزر، تکامل، زرتشت، هولوگرافیک). مدلِ **شش‌لایه‌ای**: زیستی/عصبی(A) → روان‌شناختی(A/B) → رفتاری/تمرینی → اجتماعی/جمعی(A مکانیزم) → اسطوره‌ای/فلسفی(D) → فیزیکی/ریاضی(A فیزیک؛ D نگاشت).
- **کلیدِ درجه:** A قوی · B متوسط · C فرضیه‌ی معتبرِ اثبات‌نشده · D استعاره · E شبه‌علم.
- **جدولِ ۱۰ الگوی مشترک:** هر الگو با حوزه‌ها/مکانیزم/شاهد/درجه/معادله‌ی احتمالی/خطرِ سوءبرداشت (مثلاً «ترس به سوخت» A/B؛ «تکرار تا خلسه» A خودکارسازی/B-C خلسه؛ «همفازی و تقویت» A فیزیک/B-C اجتماعی؛ «فنر» A فیزیک/D روان).
- **فرمولِ نهایی 🌀D:** P = F(ترسِ مهارشده) × D(نظمِ تکرارشونده) × I(تخیلِ همفاز) × R(رهاییِ فشرده). صریحاً **استعاری-تحلیلی، نه معادله‌ی کمّی**؛ ضرب فیزیکاً تعریف‌نشده؛ نسخه‌ی صادقانه‌تر = جمع (نه ضرب) از اجزای A/B مستقلاً تأییدشده.
- **⚠️ تنشِ داخلی (کشف‌شده):** STAGE2 زبانِ «همفازی/phase-lock/همفازیِ گاما» به کار می‌برد، اما P1 نشان داد امضای فردیِ عمق **decoupling** است. → این همان **هم‌نامیِ coherence** است؛ فرهنگِ واژگان باید disambiguate شود («decoupling/release» فردی؛ «entrainment/sync» گروهی). [این بازنویسی روی افقِ project-memory است.]
- **تناقض‌های ثبت‌شده:** هیپنوتیزمِ دامیاتو در حدِ «برنامه‌ریزیِ ذهن» سندِ اولیه ندارد؛ هم‌زمانی هم مفید هم مضر؛ استرس دوسویه؛ FMO coherence (Engel 2007 → Duan 2017 رد در دمای فیزیولوژیک)؛ دوگانه‌گراییِ پهلوی نباید به گاتاها بازتاب شود.
- **provenance:** file:STAGE2_FINAL_REPORT.md (و نسخه‌ی .pdf که **duplicate** است — همان zip/جیمیج).

---

## C — گره‌های canon (Fusion World) 【P】 — عمدتاً `[gap]`

> این پنج آرشیو (پسوندِ .pdf ولی در واقع ZIP از JPEG+txt) دچار **خرابیِ font-encoding**اند؛
> بدنه‌ی فارسی قابلِ بازسازیِ صادقانه نیست. فقط اسکلتِ خوانا استخراج شد. **هیچ بازسازی‌ای نشد.**

### C1 · سندِ کانونیِ فیوژن — رده‌ی «همتاب» (Hamtāb)
- **اسکلتِ خوانا:** موجودیتِ هوشمندِ نوظهورِ «به‌همتابانه»؛ legendِ تگ 【E】 علمِ مستقر / 【P】 برون‌بافیِ موجه / 【S】 گمانه‌ی محض؛ «قانونِ آهنین (مشترک با سندِ مبنایی)…».
- **بدنه:** `[gap — font-encoding؛ بازسازی‌نشده]`.
- **provenance:** file:fusionhamtabcanon.pdf (۵ صفحه).

### C2 · سندِ کانونیِ فیوژن — «عبور از آستانه‌ی نگارنده‌ی مرز» (Threshold Crossing)
- **اسکلتِ خوانا:** مقید به فیزیکِ واقعی؛ تعریفِ «رویدادِ عبور»؛ وضعیت = پیشنهادی؛ «قانونِ مبنا: قید = واقعیت، نه زرهِ پیرنگ (plot-armor)».
- **بدنه:** `[gap — font-encoding]`.
- **provenance:** file:fusioncanonthresholdcrossing.pdf (۵ صفحه).

### C3 · Execution Blueprint — چک‌لیست‌های عملیاتیِ فیوژن
- **اسکلتِ خوانا:** «کلِ موادِ فیوژن (کدکس، رده‌ها، صحنه‌ها، پرامپت‌ها) را به یک منبعِ واحدِ حقیقت تبدیل کن».
- **بدنه:** `[gap — font-encoding]`.
- **provenance:** file:fusionexecutionblueprint.pdf (۴ صفحه).

### C4 · Claude Project Setup
- **اسکلتِ خوانا:** جداییِ knowledge از instructions در Project؛ ATELIER؛ نسخه v1.0.
- **بدنه:** `[gap — font-encoding]`.
- **provenance:** file:CLAUDE_PROJECT_SETUP.pdf (۴ صفحه).

---

## M — دانشِ ارجاع‌شده در project-memory ولی غایب از این corpus

> جدا نگه داشته می‌شود تا با دانشِ file-grounded مخلوط نشود (register دوگانه).

- **Π/Seam framework** و **Layer 0/1/2** (arousal / directed creative focus / deep prior updating via reconsolidation). واژگانِ «Π/Seam» در فایل‌های حاضر **نیست**؛ این‌ها احتمالاً تکاملِ بعدی‌اند. `[not in corpus]`
- **فرضیه‌ی falsifiable spacing×expectancy** (۲×۲ between-subjects ANCOVA، cold-pressor). `[not in corpus]`
- **مانوئلِ Henry Cardew / Progressive Thought, Sydney** — historically unverified ⚠️؛ Trove provenance-check توصیه‌شده. `[not in corpus]`
- خروجی‌های استخراجِ قبلی (INDEX/KNOWLEDGE_CORE/GRAPH…) که memory ذکر می‌کند — در این نسخه از corpus نیستند. `[not in corpus]`

---

## پیوستِ ⚠️ — attributionهای مشکوک (Wall-4 watchlist)
- **نامِ هیپنوتیزم‌گرِ تایسون:** file:_ نام‌های «Jim Fox / John Halpin» را «در منابعِ مختلف» می‌آورد؛ اما file:STAGE2 §۶ صریحاً می‌گوید سندِ اولیه با نامِ هیپنوتراپیست **دست‌نیافتنی** است. → **تعارض؛ تا راستی‌آزماییِ بیرونی به‌عنوان confabulatedِ محتمل رفتار شود** (هم‌ردیفِ اصلِ Cardew). درجه: ⚠️ to-verify.
- **تصحیحِ تاریخ:** *Iron Ambition* = ۲۰۱۷، نه ۲۰۰۷ (file:_).
