# OPEN_QUESTIONS — سؤالاتِ باز و فرضیه‌های falsifiable

> فقط سؤالاتِ واقعاً بازِ ثبت‌شده در corpus (+ چند موردِ project-memory با علامتِ صریح).

## الف) درونِ ستونِ علمی
1. **state vs non-state هیپنوتیزم** همچنان حل‌نشده؛ هیچ زیست‌نشانگرِ قطعی «حالت» را تعریف نمی‌کند (file:P0, STAGE2 §۶).
2. **آیا «عمق» آموختنی است؟** CSTP نمره را بالا می‌برد، ولی این تغییرِ traitِ واقعی است یا compliance/گزارشِ ذهنی؟ بستگی به objective/subjective دارد (file:P3).
3. **indirect > direct (Ericksonian)** — شاهدِ مختلط؛ قطعی نیست (file:P2/P2b).
4. **tailored > standardized** — امیدوارکننده، شاهدِ head-to-head محکمِ کمی ندارد (file:P2b محور ۴).
5. آیا deepening «عمقِ objective» را بالا می‌برد یا فقط subjective report را؟ (file:P2).

## ب) سنجشِ تجربیِ شخصی (Stage-3 roadmap، file:STAGE2 §۹)
6. آیا تمرینِ تکراری-تلقینی هم‌زمانیِ ریتمیکِ قابل‌اندازه‌گیری (EEG) ایجاد می‌کند؟
7. آیا بازارزیابیِ ترس با تغییراتِ theta/gamma در mPFC مطابقت دارد؟
8. آیا فلاتِ یادگیری با نشانه‌های زودهنگامِ نقاطِ عطف (افزایشِ واریانس/autocorrelation) همبستگی دارد؟
9. آیا می‌شود متغیرهای حالتِ روان‌شناختی (اتوماتیسیته، تمرکز، همدوسیِ هویتی) را طوری تعریف کرد که واقعاً «نقطه‌ی عطف» نشان دهند؟ (بومی‌سازیِ الگوی فنر/گذارِ فاز).

## ج) مرزبندیِ canon (file:X1 + PDFهای [gap])
10. آیا «رویدادِ عبور»ِ همتاب یک رویدادِ فیزیکیِ قابل‌دفاع است یا استعاره؟ (سه مدل: ممکن‌وپرداخت‌شده / خطای مقوله‌ای / جزئیِ برگشت‌پذیر) — file:fusionpromptthresholdcrossing [اسکلت].
11. هزینه‌ی ترمودینامیکیِ «همفازیِ عبور» با Landauer/Lloyd چقدر است و گلوگاهِ مهلک کجاست؟ `[بدنه gap]`

## د) provenance / to-verify (Wall-4 watchlist)
12. **نامِ هیپنوتیزم‌گرِ تایسون** (Jim Fox / John Halpin؟) — تعارضِ file:_ با file:STAGE2؛ تا راستی‌آزماییِ بیرونی ⚠️.
13. صفحه-سطحِ دقیقِ ادعای هیپنوتیزم در *Iron Ambition* (۲۰۱۷) — دست‌نیافته (file:STAGE2 §۹).
14. **[project-memory]** مانوئلِ Cardew / Progressive Thought, Sydney — نیازمندِ Trove provenance-check؛ در corpus نیست. `[not in corpus]`

## هـ) فرضیه‌های falsifiable
15. **[project-memory]** فرضیه‌ی **spacing × expectancy** در خودتلقین (۲×۲ between-subjects ANCOVA، cold-pressor analgesia). این فایل در corpus نیست ولی روی افق است. اگر ساخته شود، به گرهِ research اضافه شود. `[not in corpus]`

## و) تصمیم‌های حاکمیتیِ روی افق (project-memory)
16. **تثبیتِ Wall 4** به‌عنوان گرهِ حاکمیتیِ رسمی (G0 هنوز فایلِ رسمی ندارد).
17. **بازنویسیِ سندِ coherence** با واژگانِ disambiguated: «decoupling/release» فردی · «entrainment/sync» گروهی — بستنِ هم‌نامی از ریشه.
18. آیا اول **predictionهای falsifiableِ بیشتر** فرمالایز شود، یا اول ساختارِ حاکمیت قفل شود؟
