# INDEX — پایگاهِ دانشِ Fusion World (نسخه‌ی Wall-4-safe)

استخراج‌شده در: ۳ ژوئیه ۲۰۲۶ · حالت: **guardrailed (گزینه‌ی ب)** · مرجعِ داخلی (نه external-facing).

## فایل‌های این knowledge base
| فایل | محتوا |
|------|-------|
| `INDEX.md` | همین فهرست + scope و provenance |
| `KNOWLEDGE_CORE.md` | استخراجِ گره‌به‌گره با تگ + provenance |
| `KNOWLEDGE_GRAPH.md` | گرافِ typed-edge (🔗/🌀/⚠️) + زیرگرافِ pivotها |
| `PROMPT_LIBRARY.md` | ۳ پرامپت + تحلیلِ Wall-4 هر کدام |
| `OPEN_QUESTIONS.md` | سؤالاتِ باز + فرضیه‌های falsifiable |
| `EXTRACTION_REPORT.md` | گزارشِ نهایی: totals، duplicateها، compliance، اعتماد |

## نقشه‌ی گره‌ها (هر گره یک‌بار)
- **حاکمیت:** G0 (Wall 4 + چهار دیوار) · G1 (scope/firewall، ATELIER)
- **research:** P0 (guardrails) · P1 (مکانیزمِ عصبی) · P2 (روش) · P2b (customization) · P3 (استعداد) · X1 (واقعی×فیوژن)
- **سنتز:** STAGE2 (مدلِ ۶لایه + فرمولِ 🌀 + ۱۰ الگو)
- **canon 【P】 (بدنه [gap]):** C1 همتاب · C2 عبور از آستانه · C3 blueprint · C4 setup
- **پرامپت:** PR1 موتورِ سنتز · PR2 عبور از آستانه · PR3 master-extraction (ari)
- **غایب از corpus [gap]:** P4، P5 (ارجاع‌شده)؛ Π/Seam، Layer 0/1/2، spacing×expectancy، Cardew (project-memory)

## Scope و provenance — چه خوانده شد، چه [gap] ماند
**خوانده‌شده و تمیز (۹ فایل):** P0, P1, P2, P2b, P3, X1, STAGE2_FINAL_REPORT.md, علم_عمیق (موتورِ سنتز), `_` (نقدِ بنیادین).
**استخراج‌شده ولی بدنه [gap] (۵ آرشیو):** fusionhamtabcanon, fusioncanonthresholdcrossing, fusionexecutionblueprint, CLAUDE_PROJECT_SETUP, fusionpromptthresholdcrossing — همه در واقع ZIP از JPEG+txt با **خرابیِ font-encoding**؛ فقط اسکلتِ خوانا استخراج شد، **بازسازی نشد**.
**duplicate:** STAGE2_FINAL_REPORT.pdf = همان .md (نگه داشته شد به‌عنوان archive، merge نشد).

## قواعدِ حاکم بر کلِ این knowledge base
1. **Wall 4:** provenance («در file:X هست») ≠ evidence («صحیح است»).
2. **بدونِ reconstruction:** شکاف = `[gap]`، نه پُلِ ساختگی.
3. **یال‌های typed:** هیچ «validated/inspired»ِ لخت؛ فقط 🔗/🌀/⚠️.
4. **حفظِ تکامل:** pivotها/duplicateها آرشیو می‌شوند، پاک نمی‌شوند.
5. **firewall:** research / canon / ATELIER جدا؛ mining از investment جدا.
6. **register دوگانه:** دانشِ file-grounded از دانشِ memory-only جدا علامت خورده.
